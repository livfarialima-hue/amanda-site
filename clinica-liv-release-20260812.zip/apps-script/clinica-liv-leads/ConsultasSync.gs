const CONSULTAS_SYNC_CONFIG = Object.freeze({
  spreadsheetId:
    "1rZJbqYcNp8FOmQNfzVed7UQOMoRo-Q818RHRyekMuMU",
  consultationsSheetName: "Consultas",
  leadSheetNames: Object.freeze([
    "Google Ads - Conversões",
    "Leads Dr. Daniel",
  ]),
  timezone: "America/Sao_Paulo",
  startHour: 9,
  endHour: 19,
  postConsultDelayMinutes: 180,
  postConsultMaxAgeDays: 7,
  postConsultRetryMinutes: 30,
  postConsultDisabledRetryMinutes: 360,
  noShowDelayMinutes: 120,
  noShowManualDelayDays: 5,
  noShowWhatsappWindowMinutes: 1430,
  postConsultEndpoint:
    "https://draamandaschroeder.com.br/.netlify/functions/post-consult-followup",
  secretProperty: "LEADS_INGEST_SECRET",
  postConsultEndpointProperty: "POS_CONSULTA_ENDPOINT",
  noShowEndpoint:
    "https://draamandaschroeder.com.br/api/scheduled-followup",
  noShowEndpointProperty: "NAO_COMPARECEU_ENDPOINT",
  syncTriggerFunction: "sincronizarConsultasAoEditar",
  postConsultTriggerFunction: "processarPosConsulta",
  defaultAppointmentDurationMinutes: 60,
  roomCalendars: Object.freeze({
    "Sala 1":
      "257c2b41ddae349c5187ad3e422a19bd57b515435f14fa7ac4f933cdac8cb164@group.calendar.google.com",
    "Sala 2":
      "8ba6ec7ba5cfca4acf42ed4ea8fb2ceb99b31ddd88e6e36da868037374d9e0bd@group.calendar.google.com",
  }),
});

const CONSULTAS_SYNC_HEADERS = Object.freeze({
  id: "ID da consulta",
  opportunityId: "Opportunity ID",
  phone: "Telefone (E.164)",
  name: "Nome do paciente",
  professional: "Profissional",
  room: "Sala",
  consultationType: "Tipo de consulta",
  topic: "Tema / procedimento",
  location: "Local / modalidade",
  scheduledDate: "Data agendada",
  scheduledTime: "Horário agendado",
  status: "Status",
  completedDate: "Data realizada",
  consent: "Consentimento para contato",
  source: "Origem do registro",
  notes: "Observações administrativas",
  postEligibleAt: "Pós-consulta elegível em",
  postSentAt: "Pós-consulta enviado",
  postLastAttempt: "Última tentativa pós-consulta",
  postLastError: "Erro pós-consulta",
  postSuppressedAt: "Pós-consulta suprimido em",
  patientConfirmedAt: "Confirmação da paciente",
  lastHumanInteractionAt: "Última interação humana",
  nextAction: "Próxima ação",
  suppressionReason: "Motivo de supressão",
  durationMinutes: "Duração (min)",
  calendarId: "ID da agenda Google",
  calendarEventId: "ID do evento Google",
  calendarSyncStatus: "Sincronização Google Agenda",
  calendarSyncError: "Erro Google Agenda",
  noShowAt: "Não comparecimento registrado em",
  noShowEligibleAt: "Retomada de ausência elegível em",
  noShowSentAt: "Retomada de ausência enviada",
  noShowLastAttempt: "Última tentativa de retomada de ausência",
  noShowLastError: "Erro na retomada de ausência",
  noShowSuppressedAt: "Retomada de ausência suprimida em",
  noShowManualAt: "Retomada manual de ausência sugerida em",
});

const CONSULTAS_SYNC_LEAD_HEADERS = Object.freeze({
  phone: "Telefone (E.164)",
  status: "Situação do lead",
  statusDate: "Data da situação",
  reference: "Referência da campanha",
  platform: "Plataforma de aquisição",
  campaign: "Campanha",
  creative: "Criativo",
  notes: "Observação administrativa",
  appointmentDate: "Data da consulta",
  appointmentTime: "Horário da consulta",
  appointmentProfessional: "Profissional da consulta",
  appointmentRoom: "Sala da consulta",
  appointmentOutcome: "Resultado do último agendamento",
  lastNoShowAt: "Último não comparecimento",
  noShowCount: "Total de não comparecimentos",
});

function chaveProfissionalConsulta_(value) {
  const normalized = normalizarTextoConsultasSync_(value);

  if (normalized.includes("amanda")) return "amanda";
  if (normalized.includes("henrique")) return "henrique";
  if (normalized.includes("marina")) return "marina";
  if (normalized.includes("laerte")) return "laerte";
  if (normalized.includes("daniel")) return "daniel";

  return "";
}

function salasPermitidasProfissional_(professional) {
  const key = chaveProfissionalConsulta_(professional);

  if (key === "amanda") return ["Sala 1"];
  if (key === "henrique" || key === "daniel") {
    return ["Sala 2"];
  }
  if (key === "marina" || key === "laerte") {
    return ["Sala 1", "Sala 2"];
  }

  return [];
}

function profissionalPermitidoAutomacaoConsulta_(professional) {
  const key = chaveProfissionalConsulta_(professional);
  return key === "amanda" || key === "daniel";
}

function normalizarSalaConsulta_(value) {
  const normalized = normalizarTextoConsultasSync_(value);
  if (/\bsala\s*1\b/.test(normalized)) return "Sala 1";
  if (/\bsala\s*2\b/.test(normalized)) return "Sala 2";
  return "";
}

function consultaOcupaSala_(input) {
  const context = normalizarTextoConsultasSync_(
    [input && input.consultationType, input && input.location].join(" "),
  );

  return !/teleconsulta|online|videochamada/.test(context);
}

function duracaoConsultaMinutos_(value) {
  const duration = Number(value);
  if (Number.isFinite(duration)) {
    return Math.max(15, Math.min(480, Math.round(duration)));
  }

  return CONSULTAS_SYNC_CONFIG.defaultAppointmentDurationMinutes;
}

function intervaloConsultaAgenda_(dateValue, timeValue, durationValue) {
  const date = extrairDataConsultasSync_(dateValue);
  const time = extrairHorarioConsultasSync_(timeValue);
  if (!date || !time) return null;

  const dateParts = date.split("-").map(Number);
  const timeParts = time.split(":").map(Number);
  const start = new Date(
    dateParts[0],
    dateParts[1] - 1,
    dateParts[2],
    timeParts[0],
    timeParts[1],
    0,
    0,
  );

  if (Number.isNaN(start.getTime())) return null;

  const durationMinutes = duracaoConsultaMinutos_(durationValue);
  const end = new Date(
    start.getTime() + durationMinutes * 60 * 1000,
  );

  return { start, end, durationMinutes };
}

function salaEstaLivreConsulta_(
  room,
  start,
  end,
  ignoredEventId,
) {
  const calendarId = CONSULTAS_SYNC_CONFIG.roomCalendars[room];
  const calendar = CalendarApp.getCalendarById(calendarId);

  if (!calendar) {
    throw new Error("calendar_not_accessible_" + room.replace(/\s/g, "_"));
  }

  const events = calendar.getEvents(start, end);
  const ignored = textoConsultasSync_(ignoredEventId, 240);
  const conflict = events.some(function (event) {
    return !ignored || event.getId() !== ignored;
  });

  return {
    free: !conflict,
    calendar,
    calendarId,
  };
}

function escolherSalaDisponivelConsulta_(input) {
  if (!consultaOcupaSala_(input || {})) {
    return { ok: true, room: "", remote: true };
  }

  const interval = intervaloConsultaAgenda_(
    input && input.scheduledDate,
    input && input.scheduledTime,
    input && input.durationMinutes,
  );
  if (!interval) return { ok: false, error: "invalid_schedule" };

  const allowed = salasPermitidasProfissional_(
    input && input.professional,
  );
  if (!allowed.length) {
    return { ok: false, error: "professional_room_rule_missing" };
  }

  const preferred = normalizarSalaConsulta_(
    input && (input.room || input.preferredRoom),
  );
  const ordered = allowed.slice();
  if (preferred && allowed.includes(preferred)) {
    ordered.splice(ordered.indexOf(preferred), 1);
    ordered.unshift(preferred);
  }

  for (let index = 0; index < ordered.length; index += 1) {
    const room = ordered[index];
    const ignoredEventId =
      normalizarSalaConsulta_(input && input.currentRoom) === room
        ? input && input.calendarEventId
        : "";
    const availability = salaEstaLivreConsulta_(
      room,
      interval.start,
      interval.end,
      ignoredEventId,
    );

    if (!availability.free) continue;

    return {
      ok: true,
      room,
      calendar: availability.calendar,
      calendarId: availability.calendarId,
      start: interval.start,
      end: interval.end,
      durationMinutes: interval.durationMinutes,
    };
  }

  return { ok: false, error: "room_not_available" };
}

function prepararAutomacaoConsultas() {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  garantirEstruturaSincronizacaoConsultas_(sheet);
  CONSULTAS_SYNC_CONFIG.leadSheetNames.forEach(function (sheetName) {
    const leadSheet = spreadsheet.getSheetByName(sheetName);
    if (leadSheet) garantirEstruturaAgendaVisivelLeads_(leadSheet);
  });

  return {
    ok: true,
    syncTriggerInstalled: existeGatilhoConsultas_(
      CONSULTAS_SYNC_CONFIG.syncTriggerFunction,
    ),
    postConsultTriggerInstalled: existeGatilhoConsultas_(
      CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
    ),
  };
}

function diagnosticarAgendaSalas() {
  const calendars = Object.keys(
    CONSULTAS_SYNC_CONFIG.roomCalendars,
  ).map(function (room) {
    const calendarId =
      CONSULTAS_SYNC_CONFIG.roomCalendars[room];
    const calendar = CalendarApp.getCalendarById(calendarId);

    return {
      room,
      calendarId,
      accessible: Boolean(calendar),
      calendarName: calendar ? calendar.getName() : "",
    };
  });

  return {
    ok: calendars.every(function (calendar) {
      return calendar.accessible;
    }),
    calendars,
    roomRules: {
      Amanda: salasPermitidasProfissional_("Dra. Amanda"),
      Henrique: salasPermitidasProfissional_("Dr. Henrique"),
      Marina: salasPermitidasProfissional_("Dra. Marina"),
      Laerte: salasPermitidasProfissional_("Dr. Laerte"),
      Daniel: salasPermitidasProfissional_("Dr. Daniel"),
    },
  };
}

function diagnosticarCabecalhosConsultas() {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  const headers = sheet
    .getRange(1, 1, 1, Math.max(sheet.getLastColumn(), 1))
    .getDisplayValues()[0];
  const diagnostic = headers.map(function (header, index) {
    return {
      column: index + 1,
      displayed: String(header || ""),
      normalized: normalizarCabecalhoConsultas_(header),
    };
  });

  console.log(JSON.stringify(diagnostic));
  return diagnostic;
}

function repararCabecalhosConsultas() {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  sheet.getRange("A1").setValue("ID da consulta");
  sheet.getRange("B1").setValue("Telefone (E.164)");
  sheet
    .getRange("AM1")
    .setValue("Agendamento monitorado");
  SpreadsheetApp.flush();

  return { ok: true, repaired: ["A1", "B1", "AM1"] };
}

function ativarAutomacaoConsultas() {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  garantirEstruturaSincronizacaoConsultas_(sheet);
  removerGatilhosConsultas_(
    CONSULTAS_SYNC_CONFIG.syncTriggerFunction,
  );
  removerGatilhosConsultas_(
    CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
  );

  ScriptApp.newTrigger(
    CONSULTAS_SYNC_CONFIG.syncTriggerFunction,
  )
    .forSpreadsheet(spreadsheet)
    .onEdit()
    .create();

  ScriptApp.newTrigger(
    CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
  )
    .timeBased()
    .everyMinutes(15)
    .create();

  return prepararAutomacaoConsultas();
}

function desativarAutomacaoConsultas() {
  removerGatilhosConsultas_(
    CONSULTAS_SYNC_CONFIG.syncTriggerFunction,
  );
  removerGatilhosConsultas_(
    CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
  );

  return { ok: true, active: false };
}

function ativarPosConsulta() {
  removerGatilhosConsultas_(
    CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
  );

  ScriptApp.newTrigger(
    CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
  )
    .timeBased()
    .everyMinutes(15)
    .create();

  return {
    ok: true,
    active: existeGatilhoConsultas_(
      CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
    ),
  };
}

function desativarPosConsulta() {
  removerGatilhosConsultas_(
    CONSULTAS_SYNC_CONFIG.postConsultTriggerFunction,
  );

  return { ok: true, active: false };
}

function existeGatilhoConsultas_(handler) {
  return ScriptApp.getProjectTriggers().some(function (trigger) {
    return trigger.getHandlerFunction() === handler;
  });
}

function removerGatilhosConsultas_(handler) {
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (trigger.getHandlerFunction() === handler) {
      ScriptApp.deleteTrigger(trigger);
    }
  });
}

function sincronizarConsultasAoEditar(e) {
  if (!e || !e.range) {
    return { ok: false, error: "missing_edit_event" };
  }

  const sheet = e.range.getSheet();
  const sheetName = sheet.getName();

  if (
    typeof CENTRAL_ATENDIMENTO_CONFIG !== "undefined" &&
    sheetName === CENTRAL_ATENDIMENTO_CONFIG.sheetName &&
    typeof processarEdicaoCentralAtendimento_ === "function"
  ) {
    return processarEdicaoCentralAtendimento_(e);
  }

  if (
    sheetName ===
    CONSULTAS_SYNC_CONFIG.consultationsSheetName
  ) {
    return processarEdicaoNaAbaConsultas_(e);
  }

  if (
    !CONSULTAS_SYNC_CONFIG.leadSheetNames.includes(sheetName)
  ) {
    return { ok: true, ignored: true };
  }

  return processarEdicaoNaAbaLeads_(e);
}

function processarEdicaoNaAbaLeads_(e) {
  const sheet = e.range.getSheet();
  const headers = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const columns = mapearCabecalhosConsultas_(headers);
  const statusColumn = columns[
    CONSULTAS_SYNC_LEAD_HEADERS.status
  ];

  if (
    statusColumn === undefined ||
    e.range.getRow() < 2 ||
    statusColumn + 1 < e.range.getColumn() ||
    statusColumn + 1 >
      e.range.getLastColumn()
  ) {
    return { ok: true, ignored: true };
  }

  const spreadsheet = sheet.getParent();
  const consultationSheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!consultationSheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  garantirEstruturaSincronizacaoConsultas_(consultationSheet);

  const professional =
    sheet.getName() === "Leads Dr. Daniel"
      ? "Dr. Daniel"
      : "Dra. Amanda";
  let synced = 0;

  for (
    let rowNumber = Math.max(2, e.range.getRow());
    rowNumber <= e.range.getLastRow();
    rowNumber += 1
  ) {
    const row = sheet
      .getRange(rowNumber, 1, 1, sheet.getLastColumn())
      .getValues()[0];
    const status = normalizarTextoConsultasSync_(
      row[statusColumn],
    );

    if (
      sheet.getName() === "Google Ads - Conversões" &&
      typeof recordLeadStageEvent_ === "function"
    ) {
      const displayRow = sheet
        .getRange(rowNumber, 1, 1, sheet.getLastColumn())
        .getDisplayValues()[0];
      const phone = valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_LEAD_HEADERS.phone,
      );
      recordLeadStageEvent_(spreadsheet, {
        opportunityId: typeof leadOpportunityId_ === "function"
          ? leadOpportunityId_(displayRow, phone)
          : "",
        phone,
        source: "human_sheet_edit",
        fromStatus: e.range.getNumRows() === 1
          ? String(e.oldValue || "")
          : "",
        proposedStatus: String(row[statusColumn] || ""),
        appliedStatus: String(row[statusColumn] || ""),
        confidence: "human",
        decision: "human_override",
        evidence: "Edição manual na fase do lead",
      });
    }

    if (!statusAgendaConsulta_(status)) continue;

    const completed = statusConsultaRealizada_(status);
    const now = new Date();
    const result = upsertConsulta_(consultationSheet, {
      appointmentId:
        "lead-" +
        normalizarTelefoneConsultasSync_(
          valorDaLinhaConsultas_(
            row,
            columns,
            CONSULTAS_SYNC_LEAD_HEADERS.phone,
          ),
        ).replace(/\D/g, "") +
        "-" +
        rowNumber,
      phone: valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_LEAD_HEADERS.phone,
      ),
      professional,
      room: valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_LEAD_HEADERS.appointmentRoom,
      ),
      consultationType: "Consulta presencial",
      location: "Clínica LIV Faria Lima",
      scheduledDate: valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_LEAD_HEADERS.appointmentDate,
      ),
      scheduledTime: valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_LEAD_HEADERS.appointmentTime,
      ),
      status: completed
        ? "Consulta realizada"
        : "Consulta agendada",
      completedAt: completed ? now : "",
      source: "Sincronização manual da aba de leads",
      notes: montarObservacaoLeadConsultas_(
        row,
        columns,
        sheet.getName(),
      ),
      queuePostConsult: completed,
      now,
    });

    if (result.ok) {
      synced += 1;
      const consultationHeaders = consultationSheet
        .getRange(1, 1, 1, consultationSheet.getLastColumn())
        .getDisplayValues()[0];
      const consultationColumns =
        mapearCabecalhosConsultas_(consultationHeaders);
      const consultationRow = consultationSheet
        .getRange(
          result.row,
          1,
          1,
          consultationSheet.getLastColumn(),
        )
        .getValues()[0];
      const calendarResult = sincronizarConsultaComAgendaNaLinha_(
        consultationSheet,
        result.row,
        consultationColumns,
        consultationRow,
      );
      if (calendarResult.room) {
        atualizarAgendaVisivelNoLead_(
          spreadsheet,
          valorDaLinhaConsultas_(
            row,
            columns,
            CONSULTAS_SYNC_LEAD_HEADERS.phone,
          ),
          professional,
          {
            scheduledDate: valorDaLinhaConsultas_(
              row,
              columns,
              CONSULTAS_SYNC_LEAD_HEADERS.appointmentDate,
            ),
            scheduledTime: valorDaLinhaConsultas_(
              row,
              columns,
              CONSULTAS_SYNC_LEAD_HEADERS.appointmentTime,
            ),
            room: calendarResult.room,
          },
        );
      }
    }
  }

  return { ok: true, synced };
}

function processarEdicaoNaAbaConsultas_(e) {
  const sheet = e.range.getSheet();
  const headers = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const columns = mapearCabecalhosConsultas_(headers);
  const operationalHeaders = [
    CONSULTAS_SYNC_HEADERS.professional,
    CONSULTAS_SYNC_HEADERS.room,
    CONSULTAS_SYNC_HEADERS.consultationType,
    CONSULTAS_SYNC_HEADERS.location,
    CONSULTAS_SYNC_HEADERS.scheduledDate,
    CONSULTAS_SYNC_HEADERS.scheduledTime,
    CONSULTAS_SYNC_HEADERS.durationMinutes,
    CONSULTAS_SYNC_HEADERS.status,
  ];
  const editedFirstColumn = e.range.getColumn();
  const editedLastColumn = e.range.getLastColumn();
  const affectsSchedule = operationalHeaders.some(function (header) {
    const column = columns[header];
    return (
      column !== undefined &&
      column + 1 >= editedFirstColumn &&
      column + 1 <= editedLastColumn
    );
  });

  if (
    e.range.getRow() < 2 ||
    !affectsSchedule
  ) {
    return { ok: true, ignored: true };
  }

  garantirEstruturaSincronizacaoConsultas_(sheet);
  const refreshedHeaders = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const refreshedColumns =
    mapearCabecalhosConsultas_(refreshedHeaders);
  let queued = 0;
  let noShowQueued = 0;
  let calendarSynced = 0;
  let calendarErrors = 0;

  for (
    let rowNumber = Math.max(2, e.range.getRow());
    rowNumber <= e.range.getLastRow();
    rowNumber += 1
  ) {
    const row = sheet
      .getRange(
        rowNumber,
        1,
        1,
        sheet.getLastColumn(),
      )
      .getValues()[0];
    const status = normalizarTextoConsultasSync_(
      row[refreshedColumns[CONSULTAS_SYNC_HEADERS.status]],
    );
    const now = new Date();

    if (statusNaoCompareceuConsulta_(status)) {
      const noShowPreparation = prepararNaoComparecimentoNaLinha_(
        sheet,
        rowNumber,
        refreshedColumns,
        row,
        now,
      );
      if (noShowPreparation.queued) noShowQueued += 1;
    }

    const calendarResult = sincronizarConsultaComAgendaNaLinha_(
      sheet,
      rowNumber,
      refreshedColumns,
      row,
    );
    if (calendarResult.ok) calendarSynced += 1;
    else calendarErrors += 1;

    const phone = valorDaLinhaConsultas_(
      row,
      refreshedColumns,
      CONSULTAS_SYNC_HEADERS.phone,
    );
    const professional = valorDaLinhaConsultas_(
      row,
      refreshedColumns,
      CONSULTAS_SYNC_HEADERS.professional,
    );
    const room = calendarResult.room || valorDaLinhaConsultas_(
      row,
      refreshedColumns,
      CONSULTAS_SYNC_HEADERS.room,
    );
    if (statusNaoCompareceuConsulta_(status)) {
      atualizarResumoNaoComparecimentoNoLead_(
        sheet.getParent(),
        sheet,
        phone,
        professional,
      );
    } else {
      atualizarStatusLeadDaConsulta_(
        sheet.getParent(),
        phone,
        professional,
        valorDaLinhaConsultas_(
          row,
          refreshedColumns,
          CONSULTAS_SYNC_HEADERS.status,
        ),
      );
    }
    atualizarAgendaVisivelNoLead_(sheet.getParent(), phone, professional, {
      scheduledDate: valorDaLinhaConsultas_(
        row,
        refreshedColumns,
        CONSULTAS_SYNC_HEADERS.scheduledDate,
      ),
      scheduledTime: valorDaLinhaConsultas_(
        row,
        refreshedColumns,
        CONSULTAS_SYNC_HEADERS.scheduledTime,
      ),
      room,
    });

    if (statusNaoCompareceuConsulta_(status)) continue;
    if (!statusConsultaRealizada_(status)) continue;

    const preparation = prepararPosConsultaNaLinha_(
      sheet,
      rowNumber,
      refreshedColumns,
      row,
      now,
    );
    if (preparation && preparation.queued) queued += 1;
  }

  return {
    ok: true,
    queued,
    noShowQueued,
    calendarSynced,
    calendarErrors,
  };
}

function upsertConsultaRecebida_(input) {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  garantirEstruturaSincronizacaoConsultas_(sheet);
  const professional = input.professional || "";
  const status = input.status || "Consulta agendada";

  if (!profissionalPermitidoAutomacaoConsulta_(professional)) {
    return { ok: false, error: "unsupported_professional" };
  }

  const result = upsertConsulta_(sheet, {
    appointmentId: input.appointmentId || input.eventId,
    opportunityId: input.opportunityId,
    phone: input.phone,
    name: input.name,
    professional,
    room: input.room,
    consultationType: input.consultationType,
    topic: input.topic,
    location:
      input.location || "Clínica LIV Faria Lima",
    scheduledDate: input.scheduledDate,
    scheduledTime: input.scheduledTime,
    durationMinutes: input.durationMinutes,
    status,
    source:
      input.source ||
      "WhatsApp — confirmação de agendamento detectada",
    notes: input.notes,
    now: new Date(),
  });

  let calendarResult = { ok: true, skipped: true, room: "" };
  if (result.ok && result.row) {
    const headers = sheet
      .getRange(1, 1, 1, sheet.getLastColumn())
      .getDisplayValues()[0];
    const columns = mapearCabecalhosConsultas_(headers);
    const row = sheet
      .getRange(result.row, 1, 1, sheet.getLastColumn())
      .getValues()[0];
    calendarResult = sincronizarConsultaComAgendaNaLinha_(
      sheet,
      result.row,
      columns,
      row,
    );
  }

  atualizarStatusLeadDaConsulta_(
    spreadsheet,
    input.phone,
    professional,
    status,
  );

  atualizarAgendaVisivelNoLead_(spreadsheet, input.phone, professional, {
    scheduledDate: input.scheduledDate,
    scheduledTime: input.scheduledTime,
    room: calendarResult.room || input.room,
  });

  return Object.assign({}, result, {
    calendarSynced: calendarResult.ok === true,
    room: calendarResult.room || input.room || "",
    calendarError:
      calendarResult.ok === true ? "" : calendarResult.error,
  });
}

function obterRelacionamentoPaciente_(input) {
  const phone = normalizarTelefoneConsultasSync_(
    input.phone,
  );

  if (!phone) {
    return relacionamentoPacienteDesconhecido_();
  }
  const requestedProfessional = chaveProfissionalConsulta_(
    input && input.professional,
  );

  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const contactPreferences =
    typeof obterPreferenciasContatoLeads_ === "function"
      ? obterPreferenciasContatoLeads_(spreadsheet, phone)
      : {
          found: false,
          neverFollowUp: false,
          neverBotReply: false,
          blockReason: "",
        };
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet || sheet.getLastRow() < 2) {
    return anexarPreferenciasRelacionamentoConsultas_(
      relacionamentoPacienteDesconhecido_(),
      contactPreferences,
    );
  }

  const headers = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const columns = mapearCabecalhosConsultas_(headers);
  const values = sheet
    .getRange(
      2,
      1,
      sheet.getLastRow() - 1,
      sheet.getLastColumn(),
    )
    .getValues();
  let best = null;

  values.forEach(function (row, index) {
    const rowPhone = normalizarTelefoneConsultasSync_(
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.phone,
      ),
    );

    if (!rowPhone || rowPhone !== phone) return;
    const rowProfessional = chaveProfissionalConsulta_(
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.professional,
      ),
    );
    if (
      requestedProfessional &&
      rowProfessional !== requestedProfessional
    ) {
      return;
    }

    const completedAt = dataConsultasSync_(
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.completedDate,
      ),
    );
    const scheduledAt = dataConsultasSync_(
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.scheduledDate,
      ),
    );
    const lastHumanAt = dataConsultasSync_(
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.lastHumanInteractionAt,
      ),
    );
    const timestamp = Math.max(
      completedAt ? completedAt.getTime() : 0,
      scheduledAt ? scheduledAt.getTime() : 0,
      lastHumanAt ? lastHumanAt.getTime() : 0,
      index + 1,
    );

    if (!best || timestamp >= best.timestamp) {
      best = {
        row: row,
        timestamp: timestamp,
        completedAt: completedAt,
        scheduledAt: scheduledAt,
      };
    }
  });

  if (!best) {
    return anexarPreferenciasRelacionamentoConsultas_(
      relacionamentoPacienteDesconhecido_(),
      contactPreferences,
    );
  }

  const status = normalizarTextoConsultasSync_(
    valorDaLinhaConsultas_(
      best.row,
      columns,
      CONSULTAS_SYNC_HEADERS.status,
    ),
  );
  const nextAction = textoConsultasSync_(
    valorDaLinhaConsultas_(
      best.row,
      columns,
      CONSULTAS_SYNC_HEADERS.nextAction,
    ),
    220,
  );
  const context = normalizarTextoConsultasSync_(
    [status, nextAction].join(" "),
  );
  const state = classificarEstadoRelacionamentoPaciente_({
    status: status,
    context: context,
    completedAt: best.completedAt,
    scheduledAt: best.scheduledAt,
    now: new Date(),
  });
  const pendingTaskType =
    classificarPendenciaRelacionamentoPaciente_(context);
  const normalizedNextAction =
    normalizarTextoConsultasSync_(nextAction);
  const hasPendingHumanTask =
    Boolean(normalizedNextAction) &&
    !/^(?:nenhuma|nenhum|sem pendencia|concluida|concluido|encerrada|encerrado)$/.test(
      normalizedNextAction,
    );

  return anexarPreferenciasRelacionamentoConsultas_({
    found: true,
    relationshipState: state,
    patientName: textoConsultasSync_(
      valorDaLinhaConsultas_(
        best.row,
        columns,
        CONSULTAS_SYNC_HEADERS.name,
      ),
      120,
    ),
    professional: textoConsultasSync_(
      valorDaLinhaConsultas_(
        best.row,
        columns,
        CONSULTAS_SYNC_HEADERS.professional,
      ),
      80,
    ),
    procedureTopic: textoConsultasSync_(
      valorDaLinhaConsultas_(
        best.row,
        columns,
        CONSULTAS_SYNC_HEADERS.topic,
      ),
      160,
    ),
    hasPendingHumanTask: hasPendingHumanTask,
    pendingTaskType: hasPendingHumanTask
      ? pendingTaskType
      : "",
  }, contactPreferences);
}

function anexarPreferenciasRelacionamentoConsultas_(
  relationship,
  preferences,
) {
  if (
    typeof anexarPreferenciasContatoRelacionamento_ ===
    "function"
  ) {
    return anexarPreferenciasContatoRelacionamento_(
      relationship,
      preferences,
    );
  }

  return Object.assign({}, relationship || {}, {
    contactPreferencesFound: preferences && preferences.found === true,
    neverFollowUp:
      preferences && preferences.neverFollowUp === true,
    neverBotReply:
      preferences && preferences.neverBotReply === true,
    blockReason: String(
      (preferences && preferences.blockReason) || "",
    ).slice(0, 240),
  });
}

function relacionamentoPacienteDesconhecido_() {
  return {
    found: false,
    relationshipState: "unknown",
    patientName: "",
    professional: "",
    procedureTopic: "",
    hasPendingHumanTask: false,
    pendingTaskType: "",
    contactPreferencesFound: false,
    neverFollowUp: false,
    neverBotReply: false,
    blockReason: "",
  };
}

function classificarEstadoRelacionamentoPaciente_(input) {
  const context = normalizarTextoConsultasSync_(
    input.context,
  );

  if (
    /pos operatorio|pos cirurgia|operad|cirurgia realizada|curativo|dreno|retorno pos/.test(
      context,
    )
  ) {
    return "active_postop";
  }

  if (
    /planejamento|orcamento.{0,30}hospital|valor.{0,30}hospital|pre operatorio|exames pre|cirurgia agendada|aguardando cirurgia|programar cirurgia/.test(
      context,
    )
  ) {
    return "surgical_planning";
  }

  if (
    /consulta agendada|agendada|confirmada/.test(
      normalizarTextoConsultasSync_(input.status),
    )
  ) {
    return "appointment_scheduled";
  }

  if (
    statusConsultaRealizada_(
      normalizarTextoConsultasSync_(input.status),
    )
  ) {
    const completedAt = dataConsultasSync_(
      input.completedAt,
    );
    const now = dataConsultasSync_(input.now) || new Date();
    const recent =
      completedAt &&
      now.getTime() - completedAt.getTime() <=
        45 * 24 * 60 * 60 * 1000;

    return recent
      ? "consultation_completed"
      : "former_patient";
  }

  return "known_patient";
}

function classificarPendenciaRelacionamentoPaciente_(context) {
  const normalized = normalizarTextoConsultasSync_(context);

  if (/hospital|orcamento|valor/.test(normalized)) {
    return "quote_or_price";
  }
  if (/agenda|horario|data|confirm/.test(normalized)) {
    return "scheduling";
  }
  if (/document|exame|laudo|termo/.test(normalized)) {
    return "documents_or_exams";
  }
  if (/cirurg|pre operatorio|pos operatorio|retorno/.test(normalized)) {
    return "care_journey";
  }
  return normalized ? "other" : "";
}

function reservarHorarioEAgendarConsulta_(input) {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const scheduleSheet = spreadsheet.getSheetByName(
    CONFIG.appointmentSlotsSheetName,
  );
  const consultationSheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!scheduleSheet) {
    return { ok: false, error: "schedule_sheet_missing" };
  }
  if (!consultationSheet) {
    return { ok: false, error: "consultations_sheet_missing" };
  }

  garantirEstruturaSincronizacaoConsultas_(
    consultationSheet,
  );
  const requestedDate =
    extrairDataConsultasSync_(input.scheduledDate);
  const requestedTime =
    extrairHorarioConsultasSync_(input.scheduledTime);
  const professionalName =
    input.professional || "Dra. Amanda";
  const requestedProfessional = normalizarTextoConsultasSync_(
    professionalName,
  );
  const requestedProfessionalKey =
    chaveProfissionalConsulta_(requestedProfessional);

  if (!profissionalPermitidoAutomacaoConsulta_(professionalName)) {
    return { ok: false, error: "unsupported_professional" };
  }

  if (!requestedDate || !requestedTime) {
    return { ok: false, error: "invalid_schedule" };
  }

  const consultationHeaders = consultationSheet
    .getRange(
      1,
      1,
      1,
      consultationSheet.getLastColumn(),
    )
    .getDisplayValues()[0];
  const consultationColumns =
    mapearCabecalhosConsultas_(consultationHeaders);
  const existingAppointmentRow =
    localizarConsultaExistente_(
      consultationSheet,
      consultationColumns,
      {
        id: input.appointmentId || input.eventId,
        phone: input.phone,
        scheduledDate: requestedDate,
        scheduledTime: requestedTime,
        incomingStatus: "Consulta agendada",
      },
    );

  if (existingAppointmentRow) {
    const existingAppointment = consultationSheet
      .getRange(
        existingAppointmentRow,
        1,
        1,
        consultationSheet.getLastColumn(),
      )
      .getValues()[0];
    const sameSchedule =
      mesmaDataConsulta_(
        existingAppointment[
          consultationColumns[
            CONSULTAS_SYNC_HEADERS.scheduledDate
          ]
        ],
        requestedDate,
      ) &&
      mesmoHorarioConsulta_(
        existingAppointment[
          consultationColumns[
            CONSULTAS_SYNC_HEADERS.scheduledTime
          ]
        ],
        requestedTime,
      );

    if (sameSchedule) {
      const duplicateCalendarResult =
        sincronizarConsultaComAgendaNaLinha_(
          consultationSheet,
          existingAppointmentRow,
          consultationColumns,
          existingAppointment,
        );
      return {
        ok: true,
        reserved: true,
        duplicate: true,
        appointmentRow: existingAppointmentRow,
        appointmentId:
          input.appointmentId || input.eventId,
        scheduledDate: requestedDate,
        scheduledTime: requestedTime,
        room:
          duplicateCalendarResult.room ||
          valorDaLinhaConsultas_(
            existingAppointment,
            consultationColumns,
            CONSULTAS_SYNC_HEADERS.room,
          ),
        calendarSynced: duplicateCalendarResult.ok === true,
      };
    }
  }

  const lastRow = scheduleSheet.getLastRow();
  if (lastRow <= CONFIG.appointmentSlotsHeaderRow) {
    return { ok: false, error: "slot_not_available" };
  }

  const values = scheduleSheet.getRange(
    CONFIG.appointmentSlotsHeaderRow,
    1,
    lastRow - CONFIG.appointmentSlotsHeaderRow + 1,
    CONFIG.appointmentSlotsColumns,
  ).getDisplayValues();
  const headers = values[0] || [];
  const columns = {
    date: findScheduleColumn_(headers, "Data"),
    time: findScheduleColumn_(headers, "Horário"),
    status: findScheduleColumn_(headers, "Status"),
    professional: findScheduleColumn_(
      headers,
      "Profissional",
    ),
    observation: findScheduleColumn_(
      headers,
      "Observação",
    ),
  };

  if (
    columns.date < 0 ||
    columns.time < 0 ||
    columns.status < 0 ||
    columns.professional < 0
  ) {
    return {
      ok: false,
      error: "unexpected_schedule_structure",
    };
  }

  let selectedRow = null;

  for (let index = 1; index < values.length; index += 1) {
    const row = values[index];
    const rowDate = extrairDataConsultasSync_(
      row[columns.date],
    );
    const rowTime = extrairHorarioConsultasSync_(
      row[columns.time],
    );
    const rowProfessional = normalizarTextoConsultasSync_(
      row[columns.professional],
    );

    if (
      rowDate !== requestedDate ||
      rowTime !== requestedTime ||
      (
        requestedProfessional &&
        (!requestedProfessionalKey ||
          !rowProfessional.includes(requestedProfessionalKey))
      )
    ) {
      continue;
    }

    if (
      normalizarTextoConsultasSync_(
        row[columns.status],
      ) !== "disponivel"
    ) {
      return { ok: false, error: "slot_not_available" };
    }

    selectedRow = {
      rowNumber:
        CONFIG.appointmentSlotsHeaderRow + index,
      status: row[columns.status],
      observation:
        columns.observation >= 0
          ? row[columns.observation]
          : "",
    };
    break;
  }

  if (!selectedRow) {
    return { ok: false, error: "slot_not_available" };
  }

  const roomSelection = escolherSalaDisponivelConsulta_({
    professional: professionalName,
    room: input.room,
    consultationType:
      input.consultationType || "Consulta presencial",
    location: input.location || "Clínica LIV Faria Lima",
    scheduledDate: requestedDate,
    scheduledTime: requestedTime,
    durationMinutes: input.durationMinutes,
  });

  if (!roomSelection.ok) {
    return {
      ok: false,
      error: roomSelection.error,
    };
  }

  const statusRange = scheduleSheet.getRange(
    selectedRow.rowNumber,
    columns.status + 1,
  );
  const observationRange =
    columns.observation >= 0
      ? scheduleSheet.getRange(
          selectedRow.rowNumber,
          columns.observation + 1,
        )
      : null;

  statusRange.setValue("Bloqueado");
  if (observationRange) {
    observationRange.setValue(
      "Agendamento confirmado via WhatsApp em " +
        Utilities.formatDate(
          new Date(),
          CONSULTAS_SYNC_CONFIG.timezone,
          "dd/MM/yyyy HH:mm",
        ),
    );
  }
  SpreadsheetApp.flush();

  try {
    const consultationResult = upsertConsulta_(
      consultationSheet,
      {
        appointmentId:
          input.appointmentId || input.eventId,
        phone: input.phone,
        name: input.name,
        professional: professionalName,
        room: roomSelection.room,
        consultationType:
          input.consultationType ||
          "Consulta presencial",
        topic: input.topic,
        location:
          input.location || "Clínica LIV Faria Lima",
        scheduledDate: requestedDate,
        scheduledTime: requestedTime,
        durationMinutes: roomSelection.durationMinutes,
        status: "Consulta agendada",
        source:
          input.source ||
          "WhatsApp — opção de horário escolhida pela paciente",
        notes: input.notes,
        now: new Date(),
      },
    );

    if (!consultationResult.ok) {
      throw new Error(
        consultationResult.error || "consultation_upsert_failed",
      );
    }

    const refreshedHeaders = consultationSheet
      .getRange(1, 1, 1, consultationSheet.getLastColumn())
      .getDisplayValues()[0];
    const refreshedColumns =
      mapearCabecalhosConsultas_(refreshedHeaders);
    const consultationRow = consultationSheet
      .getRange(
        consultationResult.row,
        1,
        1,
        consultationSheet.getLastColumn(),
      )
      .getValues()[0];
    const calendarResult = sincronizarConsultaComAgendaNaLinha_(
      consultationSheet,
      consultationResult.row,
      refreshedColumns,
      consultationRow,
    );

    atualizarStatusLeadDaConsulta_(
      spreadsheet,
      input.phone,
      professionalName,
      "Consulta agendada",
    );
    atualizarAgendaVisivelNoLead_(spreadsheet, input.phone, professionalName, {
      scheduledDate: requestedDate,
      scheduledTime: requestedTime,
      room: calendarResult.room || roomSelection.room,
    });
    SpreadsheetApp.flush();

    return {
      ok: true,
      reserved: true,
      scheduleRow: selectedRow.rowNumber,
      appointmentRow: consultationResult.row,
      appointmentId: consultationResult.appointmentId,
      scheduledDate: requestedDate,
      scheduledTime: requestedTime,
      room: calendarResult.room || roomSelection.room,
      calendarSynced: calendarResult.ok === true,
      calendarError:
        calendarResult.ok === true ? "" : calendarResult.error,
    };
  } catch (error) {
    statusRange.setValue(selectedRow.status || "Disponível");
    if (observationRange) {
      observationRange.setValue(
        selectedRow.observation || "",
      );
    }
    SpreadsheetApp.flush();
    throw error;
  }
}

function registrarInteracaoHumanaDaConsulta_(input) {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  garantirEstruturaSincronizacaoConsultas_(sheet);
  const headers = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const columns = mapearCabecalhosConsultas_(headers);
  const now = dataConsultasSync_(input.at) || new Date();
  const rowNumber = localizarConsultaParaAtualizacao_(
    sheet,
    columns,
    input,
    now,
  );

  if (!rowNumber) {
    return { ok: true, updated: false, reason: "appointment_not_found" };
  }

  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.lastHumanInteractionAt,
    now,
  );

  return { ok: true, updated: true, row: rowNumber };
}

function registrarRespostaPacienteDaConsulta_(input) {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  garantirEstruturaSincronizacaoConsultas_(sheet);
  const headers = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const columns = mapearCabecalhosConsultas_(headers);
  const now = dataConsultasSync_(input.at) || new Date();
  const rowNumber = localizarConsultaParaAtualizacao_(
    sheet,
    columns,
    input,
    now,
    true,
  );

  if (!rowNumber) {
    return { ok: true, updated: false, reason: "appointment_not_found" };
  }

  const state = normalizarTextoConsultasSync_(input.state);

  if (state === "confirmed") {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.status,
      "Consulta confirmada",
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.patientConfirmedAt,
      now,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.nextAction,
      "",
    );
  } else if (state === "reschedule_requested") {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.status,
      "Reagendamento solicitado",
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.nextAction,
      "Equipe: confirmar nova data e horário antes de nova mensagem.",
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.suppressionReason,
      "Lembretes suspensos: paciente pediu reagendamento.",
    );
  } else {
    return { ok: true, updated: false, reason: "unsupported_state" };
  }

  atualizarStatusLeadDaConsulta_(
    spreadsheet,
    input.phone,
    input.professional || "Dra. Amanda",
    state === "confirmed"
      ? "Consulta confirmada"
      : "Reagendamento solicitado",
  );

  return { ok: true, updated: true, row: rowNumber, state };
}

function localizarConsultaParaAtualizacao_(
  sheet,
  columns,
  input,
  now,
  apenasAtiva,
) {
  if (sheet.getLastRow() < 2) return null;

  const appointmentId = textoConsultasSync_(
    input.appointmentId || input.eventId,
    180,
  );
  const phone = normalizarTelefoneConsultasSync_(input.phone);
  const requestedProfessional = chaveProfissionalConsulta_(
    input.professional,
  );
  const values = sheet
    .getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn())
    .getValues();
  let best = null;

  for (let index = 0; index < values.length; index += 1) {
    const row = values[index];
    const rowNumber = index + 2;
    const rowId = textoConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.id]],
      180,
    );

    if (appointmentId && rowId === appointmentId) return rowNumber;
    if (
      !phone ||
      normalizarTelefoneConsultasSync_(
        row[columns[CONSULTAS_SYNC_HEADERS.phone]],
      ) !== phone
    ) {
      continue;
    }
    if (
      requestedProfessional &&
      chaveProfissionalConsulta_(
        row[columns[CONSULTAS_SYNC_HEADERS.professional]],
      ) !== requestedProfessional
    ) {
      continue;
    }

    const status = normalizarTextoConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.status]],
    );
    const completed = statusConsultaRealizada_(status);
    const closed = statusConsultaEncerrada_(status);
    if (apenasAtiva && closed) continue;

    const completedAt = dataConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.completedDate]],
    );
    const scheduledAt = dataConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.scheduledDate]],
    );
    const isRecentCompleted =
      completed &&
      completedAt &&
      now.getTime() - completedAt.getTime() <=
        7 * 24 * 60 * 60 * 1000;
    const score = apenasAtiva
      ? scheduledAt
        ? scheduledAt.getTime()
        : rowNumber
      : isRecentCompleted
        ? 10000000000000 + completedAt.getTime()
        : scheduledAt
          ? scheduledAt.getTime()
          : rowNumber;

    if (!best || score > best.score) {
      best = { rowNumber, score };
    }
  }

  return best ? best.rowNumber : null;
}

function upsertConsulta_(sheet, input) {
  const headers = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const columns = mapearCabecalhosConsultas_(headers);
  const phone = normalizarTelefoneConsultasSync_(input.phone);

  if (!phone) {
    return { ok: false, error: "invalid_phone" };
  }

  const now =
    input.now instanceof Date ? input.now : new Date();
  const existingRow = localizarConsultaExistente_(
    sheet,
    columns,
    {
      id: input.appointmentId,
      opportunityId: input.opportunityId,
      phone,
      professional: input.professional,
      scheduledDate: input.scheduledDate,
      scheduledTime: input.scheduledTime,
      incomingStatus: input.status,
    },
  );
  const rowNumber =
    existingRow || primeiraLinhaLivreConsultas_(sheet, columns);
  const current = sheet
    .getRange(rowNumber, 1, 1, sheet.getLastColumn())
    .getValues()[0];
  const appointmentId =
    textoConsultasSync_(input.appointmentId, 180) ||
    textoConsultasSync_(
      current[columns[CONSULTAS_SYNC_HEADERS.id]],
      180,
    ) ||
    construirIdConsulta_(phone, input, rowNumber, now);

  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.id,
    appointmentId,
  );
  if (input.opportunityId) {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.opportunityId,
      textoConsultasSync_(input.opportunityId, 180),
    );
  }
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.phone,
    phone,
  );

  [
    [CONSULTAS_SYNC_HEADERS.name, input.name],
    [
      CONSULTAS_SYNC_HEADERS.professional,
      input.professional || "",
    ],
    [CONSULTAS_SYNC_HEADERS.room, input.room],
    [
      CONSULTAS_SYNC_HEADERS.consultationType,
      input.consultationType,
    ],
    [CONSULTAS_SYNC_HEADERS.topic, input.topic],
    [CONSULTAS_SYNC_HEADERS.location, input.location],
    [
      CONSULTAS_SYNC_HEADERS.scheduledDate,
      input.scheduledDate,
    ],
    [
      CONSULTAS_SYNC_HEADERS.scheduledTime,
      input.scheduledTime,
    ],
    [
      CONSULTAS_SYNC_HEADERS.durationMinutes,
      input.durationMinutes,
    ],
    [CONSULTAS_SYNC_HEADERS.status, input.status],
    [CONSULTAS_SYNC_HEADERS.source, input.source],
    [CONSULTAS_SYNC_HEADERS.notes, input.notes],
  ].forEach(function (entry) {
    if (entry[1] !== undefined && entry[1] !== "") {
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        entry[0],
        entry[1],
      );
    }
  });

  const changedSchedule =
    input.scheduledDate &&
    input.scheduledTime &&
    (!mesmaDataConsulta_(
      current[columns[CONSULTAS_SYNC_HEADERS.scheduledDate]],
      input.scheduledDate,
    ) ||
      !mesmoHorarioConsulta_(
        current[columns[CONSULTAS_SYNC_HEADERS.scheduledTime]],
        input.scheduledTime,
      ));

  if (changedSchedule) {
    [
      CONSULTAS_SYNC_HEADERS.patientConfirmedAt,
      CONSULTAS_SYNC_HEADERS.nextAction,
      CONSULTAS_SYNC_HEADERS.suppressionReason,
    ].forEach(function (header) {
      definirValorConsulta_(sheet, rowNumber, columns, header, "");
    });
  }

  if (input.completedAt) {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.completedDate,
      input.completedAt,
    );
  }

  if (input.queuePostConsult) {
    const refreshed = sheet
      .getRange(rowNumber, 1, 1, sheet.getLastColumn())
      .getValues()[0];
    prepararPosConsultaNaLinha_(
      sheet,
      rowNumber,
      columns,
      refreshed,
      now,
    );
  }

  SpreadsheetApp.flush();

  return {
    ok: true,
    created: !existingRow,
    updated: Boolean(existingRow),
    row: rowNumber,
    appointmentId,
  };
}

function statusCancelaAgendaConsulta_(value) {
  return ["cancelada", "consulta cancelada"].includes(
    normalizarTextoConsultasSync_(value),
  );
}

function statusNaoCompareceuConsulta_(value) {
  return ["nao compareceu", "consulta nao compareceu"].includes(
    normalizarTextoConsultasSync_(value),
  );
}

function statusConsultaEncerrada_(value) {
  const normalized = normalizarTextoConsultasSync_(value);
  return (
    statusConsultaRealizada_(normalized) ||
    statusCancelaAgendaConsulta_(normalized) ||
    statusNaoCompareceuConsulta_(normalized)
  );
}

function excluirEventoAgendaConsulta_(calendarId, eventId) {
  if (!calendarId || !eventId) return false;

  const calendar = CalendarApp.getCalendarById(calendarId);
  if (!calendar) return false;

  const event = calendar.getEventById(eventId);
  if (!event) return false;

  event.deleteEvent();
  return true;
}

function sincronizarConsultaComAgendaNaLinha_(
  sheet,
  rowNumber,
  columns,
  row,
) {
  const professional = textoConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.professional,
    ),
    80,
  );
  const scheduledDate = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.scheduledDate,
  );
  const scheduledTime = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.scheduledTime,
  );
  const consultationType = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.consultationType,
  );
  const location = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.location,
  );
  const durationMinutes = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.durationMinutes,
  );
  const currentRoom = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.room,
  );
  const currentCalendarId = textoConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarId,
    ),
    240,
  );
  const currentEventId = textoConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarEventId,
    ),
    240,
  );
  const status = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.status,
  );

  try {
    if (statusCancelaAgendaConsulta_(status)) {
      excluirEventoAgendaConsulta_(
        currentCalendarId,
        currentEventId,
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarEventId,
        "",
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarSyncStatus,
        "Cancelado no Google Agenda",
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarSyncError,
        "",
      );
      return {
        ok: true,
        cancelled: true,
        room: normalizarSalaConsulta_(currentRoom),
      };
    }

    if (!professional || !scheduledDate || !scheduledTime) {
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarSyncStatus,
        "Pendente — completar profissional, data e horário",
      );
      return {
        ok: true,
        skipped: true,
        room: normalizarSalaConsulta_(currentRoom),
      };
    }

    const selection = escolherSalaDisponivelConsulta_({
      professional,
      room: currentRoom,
      currentRoom,
      consultationType,
      location,
      scheduledDate,
      scheduledTime,
      durationMinutes,
      calendarEventId: currentEventId,
    });

    if (!selection.ok) {
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarSyncStatus,
        "Erro de sincronização",
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarSyncError,
        selection.error,
      );
      return {
        ok: false,
        error: selection.error,
        room: normalizarSalaConsulta_(currentRoom),
      };
    }

    if (selection.remote) {
      excluirEventoAgendaConsulta_(
        currentCalendarId,
        currentEventId,
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.room,
        "",
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarId,
        "",
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarEventId,
        "",
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarSyncStatus,
        "Não se aplica — atendimento remoto",
      );
      definirValorConsulta_(
        sheet,
        rowNumber,
        columns,
        CONSULTAS_SYNC_HEADERS.calendarSyncError,
        "",
      );
      return { ok: true, skipped: true, remote: true, room: "" };
    }

    const noShow = statusNaoCompareceuConsulta_(status);
    const title =
      (noShow ? "Não compareceu — " : "Consulta — ") +
      professional;
    const description =
      "Reserva operacional vinculada à aba Consultas. " +
      "Dados da paciente permanecem somente na planilha." +
      (noShow
        ? " Resultado operacional: não compareceu."
        : "");
    const eventLocation =
      "Clínica LIV Faria Lima — " + selection.room;
    let event = null;

    if (
      currentEventId &&
      currentCalendarId === selection.calendarId
    ) {
      event = selection.calendar.getEventById(currentEventId);
    }

    if (!event) {
      event = selection.calendar.createEvent(
        title,
        selection.start,
        selection.end,
        {
          description,
          location: eventLocation,
        },
      );

      if (
        currentEventId &&
        currentCalendarId &&
        currentCalendarId !== selection.calendarId
      ) {
        excluirEventoAgendaConsulta_(
          currentCalendarId,
          currentEventId,
        );
      }
    } else {
      event.setTitle(title);
      event.setTime(selection.start, selection.end);
      event.setDescription(description);
      event.setLocation(eventLocation);
    }

    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.room,
      selection.room,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.durationMinutes,
      selection.durationMinutes,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarId,
      selection.calendarId,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarEventId,
      event.getId(),
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarSyncStatus,
      "Sincronizado em " +
        Utilities.formatDate(
          new Date(),
          CONSULTAS_SYNC_CONFIG.timezone,
          "dd/MM/yyyy HH:mm",
        ),
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarSyncError,
      "",
    );

    return {
      ok: true,
      room: selection.room,
      calendarId: selection.calendarId,
      calendarEventId: event.getId(),
    };
  } catch (error) {
    const message = textoConsultasSync_(
      error && error.message ? error.message : error,
      240,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarSyncStatus,
      "Erro de sincronização",
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.calendarSyncError,
      message,
    );

    return {
      ok: false,
      error: message || "calendar_sync_failed",
      room: normalizarSalaConsulta_(currentRoom),
    };
  }
}

function localizarConsultaExistente_(sheet, columns, input) {
  if (sheet.getLastRow() < 2) return null;

  const values = sheet
    .getRange(
      2,
      1,
      sheet.getLastRow() - 1,
      sheet.getLastColumn(),
    )
    .getValues();
  const requestedId = textoConsultasSync_(input.id, 180);
  const requestedOpportunityId = textoConsultasSync_(
    input.opportunityId,
    180,
  );
  const requestedPhone =
    normalizarTelefoneConsultasSync_(input.phone);
  const requestedProfessional = chaveProfissionalConsulta_(
    input.professional,
  );
  const incomingCompleted = statusConsultaRealizada_(
    normalizarTextoConsultasSync_(input.incomingStatus),
  );
  let latestActiveRow = null;
  let latestActiveTimestamp = -1;

  for (let index = 0; index < values.length; index += 1) {
    const row = values[index];
    const rowNumber = index + 2;
    const rowId = textoConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.id]],
      180,
    );

    if (requestedId && rowId === requestedId) {
      return rowNumber;
    }
    const rowOpportunityId = textoConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.opportunityId]],
      180,
    );
    if (
      requestedOpportunityId &&
      rowOpportunityId === requestedOpportunityId
    ) {
      return rowNumber;
    }

    const rowPhone = normalizarTelefoneConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.phone]],
    );

    if (!rowPhone || rowPhone !== requestedPhone) continue;
    if (
      requestedProfessional &&
      chaveProfissionalConsulta_(
        row[columns[CONSULTAS_SYNC_HEADERS.professional]],
      ) !== requestedProfessional
    ) {
      continue;
    }

    if (
      input.scheduledDate &&
      input.scheduledTime &&
      mesmaDataConsulta_(
        row[columns[CONSULTAS_SYNC_HEADERS.scheduledDate]],
        input.scheduledDate,
      ) &&
      mesmoHorarioConsulta_(
        row[columns[CONSULTAS_SYNC_HEADERS.scheduledTime]],
        input.scheduledTime,
      )
    ) {
      return rowNumber;
    }

    const rowStatus = normalizarTextoConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.status]],
    );
    const active = ![
      "consulta realizada",
      "realizada",
      "cancelada",
      "consulta cancelada",
      "nao compareceu",
      "consulta nao compareceu",
    ].includes(rowStatus);

    if (!active && !incomingCompleted) continue;
    if (!active && incomingCompleted) continue;

    const scheduledDate =
      row[columns[CONSULTAS_SYNC_HEADERS.scheduledDate]];
    const timestamp =
      scheduledDate instanceof Date
        ? scheduledDate.getTime()
        : rowNumber;

    if (timestamp >= latestActiveTimestamp) {
      latestActiveRow = rowNumber;
      latestActiveTimestamp = timestamp;
    }
  }

  return latestActiveRow;
}

function primeiraLinhaLivreConsultas_(sheet, columns) {
  const idColumn = columns[CONSULTAS_SYNC_HEADERS.id] + 1;
  const maximumRows = sheet.getMaxRows();
  const values = sheet
    .getRange(2, idColumn, Math.max(maximumRows - 1, 1), 1)
    .getDisplayValues();

  for (let index = 0; index < values.length; index += 1) {
    if (!String(values[index][0] || "").trim()) {
      return index + 2;
    }
  }

  sheet.insertRowsAfter(maximumRows, 100);
  return maximumRows + 1;
}

function dataHoraAgendadaConsulta_(row, columns) {
  const interval = intervaloConsultaAgenda_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.scheduledDate,
    ),
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.scheduledTime,
    ),
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.durationMinutes,
    ),
  );

  return interval ? interval.start : null;
}

function contarNaoComparecimentosConsulta_(
  sheet,
  columns,
  phoneValue,
  professionalValue,
) {
  const phone = normalizarTelefoneConsultasSync_(phoneValue);
  const professional = chaveProfissionalConsulta_(professionalValue);

  if (!phone || !professional || sheet.getLastRow() < 2) return 0;

  const values = sheet
    .getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn())
    .getValues();

  return values.filter(function (row) {
    return (
      normalizarTelefoneConsultasSync_(
        row[columns[CONSULTAS_SYNC_HEADERS.phone]],
      ) === phone &&
      chaveProfissionalConsulta_(
        row[columns[CONSULTAS_SYNC_HEADERS.professional]],
      ) === professional &&
      statusNaoCompareceuConsulta_(
        row[columns[CONSULTAS_SYNC_HEADERS.status]],
      )
    );
  }).length;
}

function proximaRetomadaManualAusencia_(date) {
  const target = new Date(
    date.getTime() +
      CONSULTAS_SYNC_CONFIG.noShowManualDelayDays *
        24 *
        60 *
        60 *
        1000,
  );
  const localDate = Utilities.formatDate(
    target,
    CONSULTAS_SYNC_CONFIG.timezone,
    "yyyy-MM-dd",
  );

  return new Date(`${localDate}T10:30:00-03:00`);
}

function prepararNaoComparecimentoNaLinha_(
  sheet,
  rowNumber,
  columns,
  row,
  now,
) {
  const scheduledAt = dataHoraAgendadaConsulta_(row, columns);

  if (!scheduledAt) {
    return { queued: false, reason: "missing_schedule" };
  }
  if (scheduledAt.getTime() > now.getTime() + 5 * 60 * 1000) {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.nextAction,
      "Revisar: não comparecimento marcado antes do horário da consulta.",
    );
    return { queued: false, reason: "appointment_not_due" };
  }

  const sentAt = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowSentAt,
  );
  const suppressedAt = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowSuppressedAt,
  );
  if (sentAt || suppressedAt) {
    return { queued: false, reason: "already_resolved" };
  }

  const registeredAt =
    dataConsultasSync_(
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.noShowAt,
      ),
    ) || now;
  const baseEligibility = new Date(
    scheduledAt.getTime() +
      CONSULTAS_SYNC_CONFIG.noShowDelayMinutes * 60 * 1000,
  );
  const eligibleAt = proximoHorarioDeCuidadoConsultas_(
    new Date(
      Math.max(
        baseEligibility.getTime(),
        now.getTime() + 5 * 60 * 1000,
      ),
    ),
  );
  const phone = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.phone,
  );
  const professional = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.professional,
  );
  const count = contarNaoComparecimentosConsulta_(
    sheet,
    columns,
    phone,
    professional,
  );

  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowAt,
    registeredAt,
  );
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowEligibleAt,
    eligibleAt,
  );
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.postSuppressedAt,
    now,
  );
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.suppressionReason,
    "Pós-consulta não se aplica: paciente não compareceu.",
  );
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.nextAction,
    count >= 2
      ? "Equipe: avaliar pessoalmente um eventual reagendamento; há faltas anteriores."
      : "Retomar com acolhimento para oferecer reagendamento, sem cobrança.",
  );

  if (count >= 2) {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowLastError,
      "repeat_no_show_manual",
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowManualAt,
      eligibleAt,
    );
  }

  return {
    queued: count < 2,
    manual: count >= 2,
    count,
    eligibleAt,
  };
}

function prepararPosConsultaNaLinha_(
  sheet,
  rowNumber,
  columns,
  row,
  now,
) {
  const sentColumn =
    columns[CONSULTAS_SYNC_HEADERS.postSentAt];
  const eligibleColumn =
    columns[CONSULTAS_SYNC_HEADERS.postEligibleAt];
  const completedColumn =
    columns[CONSULTAS_SYNC_HEADERS.completedDate];
  const consentColumn =
    columns[CONSULTAS_SYNC_HEADERS.consent];
  const sourceColumn =
    columns[CONSULTAS_SYNC_HEADERS.source];

  if (
    sentColumn === undefined ||
    eligibleColumn === undefined ||
    completedColumn === undefined
  ) {
    return { queued: false, reason: "missing_columns" };
  }

  if (row[sentColumn]) {
    return { queued: false, reason: "already_sent" };
  }

  if (
    !consentimentoPermiteContatoConsultas_(
      consentColumn === undefined ? "" : row[consentColumn],
      sourceColumn === undefined ? "" : row[sourceColumn],
    )
  ) {
    return {
      queued: false,
      reason: "consent_not_confirmed",
    };
  }

  const completedAt =
    dataConsultasSync_(row[completedColumn]) || now;
  const completionCheck =
    validarRecenciaPosConsulta_(completedAt, now);

  if (!completionCheck.ok) {
    return { queued: false, reason: completionCheck.reason };
  }

  if (!row[completedColumn]) {
    sheet
      .getRange(rowNumber, completedColumn + 1)
      .setValue(now);
  }

  if (!row[eligibleColumn]) {
    sheet
      .getRange(rowNumber, eligibleColumn + 1)
      .setValue(
        proximoHorarioDeCuidadoConsultas_(
          new Date(
            now.getTime() +
              CONSULTAS_SYNC_CONFIG.postConsultDelayMinutes *
                60 *
                1000,
          ),
        ),
      );
  }

  return { queued: true, reason: "prepared" };
}

function proximoHorarioDeCuidadoConsultas_(date) {
  if (estaNoHorarioConsultasSync_(date)) return date;

  const localDate = Utilities.formatDate(
    date,
    CONSULTAS_SYNC_CONFIG.timezone,
    "yyyy-MM-dd",
  );
  const hour = Number(
    Utilities.formatDate(
      date,
      CONSULTAS_SYNC_CONFIG.timezone,
      "H",
    ),
  );

  if (hour < CONSULTAS_SYNC_CONFIG.startHour) {
    return new Date(
      `${localDate}T${String(
        CONSULTAS_SYNC_CONFIG.startHour,
      ).padStart(2, "0")}:00:00-03:00`,
    );
  }

  const nextDay = new Date(date.getTime() + 24 * 60 * 60 * 1000);
  const nextLocalDate = Utilities.formatDate(
    nextDay,
    CONSULTAS_SYNC_CONFIG.timezone,
    "yyyy-MM-dd",
  );

  return new Date(
    `${nextLocalDate}T${String(
      CONSULTAS_SYNC_CONFIG.startHour,
    ).padStart(2, "0")}:00:00-03:00`,
  );
}

function processarPosConsulta() {
  const now = new Date();

  if (!estaNoHorarioConsultasSync_(now)) {
    return {
      ok: true,
      sent: 0,
      reason: "outside_send_window",
    };
  }

  const properties = PropertiesService.getScriptProperties();
  const secret = properties.getProperty(
    CONSULTAS_SYNC_CONFIG.secretProperty,
  );

  if (!secret) {
    throw new Error(
      "A propriedade LEADS_INGEST_SECRET não está configurada.",
    );
  }

  const lock = LockService.getScriptLock();

  if (!lock.tryLock(5000)) {
    return { ok: false, sent: 0, error: "busy_retry" };
  }

  try {
    return processarPosConsultaInterno_(
      now,
      secret,
      properties,
    );
  } finally {
    lock.releaseLock();
  }
}

function processarPosConsultaInterno_(
  now,
  secret,
  properties,
) {
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  garantirEstruturaSincronizacaoConsultas_(sheet);

  if (sheet.getLastRow() < 2) {
    return { ok: true, sent: 0, failed: 0 };
  }

  const values = sheet.getDataRange().getValues();
  const columns = mapearCabecalhosConsultas_(values[0]);
  const leadsSheet = spreadsheet.getSheetByName(CONFIG.sheetName);
  const preferencesByPhone =
    typeof carregarPreferenciasContatoPorTelefone_ ===
    "function"
      ? carregarPreferenciasContatoPorTelefone_(leadsSheet)
      : {};
  const messagesSheet = spreadsheet.getSheetByName(
    typeof CONFIG !== "undefined" && CONFIG.messageSheetName
      ? CONFIG.messageSheetName
      : "_WHATSAPP_MENSAGENS",
  );
  const conversationsByPhone =
    messagesSheet &&
    typeof carregarConversasRetomadas_ === "function"
      ? carregarConversasRetomadas_(messagesSheet)
      : {};
  let sent = 0;
  let failed = 0;
  let suppressed = 0;
  let noShowSent = 0;
  let noShowManual = 0;
  let noShowSuppressed = 0;
  const skipped = {};

  for (let index = 1; index < values.length; index += 1) {
    const row = values[index];
    const rowNumber = index + 1;

    const normalizedPhone =
      typeof normalizarTelefonePreferenciaContato_ ===
      "function"
        ? normalizarTelefonePreferenciaContato_(
            row[columns[CONSULTAS_SYNC_HEADERS.phone]],
          )
        : "";
    const contactPreferences =
      preferencesByPhone[normalizedPhone] || {};
    try {
      const rowStatus = valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.status,
      );
      if (statusNaoCompareceuConsulta_(rowStatus)) {
        const noShowResult = processarRetomadaNaoComparecimentoNaLinha_(
          sheet,
          rowNumber,
          columns,
          row,
          now,
          secret,
          properties,
          contactPreferences,
          conversationsByPhone[normalizedPhone] || [],
        );
        if (noShowResult.sent) noShowSent += 1;
        if (noShowResult.manual) noShowManual += 1;
        if (noShowResult.suppressed) noShowSuppressed += 1;
        if (noShowResult.failed) failed += 1;
        if (noShowResult.reason) {
          skipped[noShowResult.reason] =
            (skipped[noShowResult.reason] || 0) + 1;
        }
        continue;
      }

      if (
        contactPreferences.neverFollowUp === true ||
        contactPreferences.neverBotReply === true
      ) {
        skipped.contact_preference =
          (skipped.contact_preference || 0) + 1;
        continue;
      }

      const eligibility = avaliarElegibilidadePosConsulta_(
        row,
        columns,
        now,
      );

    if (!eligibility.eligible) {
      skipped[eligibility.reason] =
        (skipped[eligibility.reason] || 0) + 1;
      continue;
    }

    const completedAt = eligibility.completedAt;
    const humanInteractionAt = dataConsultasSync_(
      row[
        columns[CONSULTAS_SYNC_HEADERS.lastHumanInteractionAt]
      ],
    );

    if (
      completedAt &&
      humanInteractionAt &&
      humanInteractionAt.getTime() >= completedAt.getTime()
    ) {
      sheet
        .getRange(
          rowNumber,
          columns[CONSULTAS_SYNC_HEADERS.postSuppressedAt] + 1,
        )
        .setValue(now);
      sheet
        .getRange(
          rowNumber,
          columns[CONSULTAS_SYNC_HEADERS.suppressionReason] + 1,
        )
        .setValue(
          "Pós-consulta dispensado: houve interação humana posterior.",
        );
      suppressed += 1;
      continue;
    }

    const lastAttempt = dataConsultasSync_(
      row[columns[CONSULTAS_SYNC_HEADERS.postLastAttempt]],
    );
    const lastError = String(
      row[columns[CONSULTAS_SYNC_HEADERS.postLastError]] ||
        "",
    );
    const retryMinutes = /disabled|template|http_400/i.test(
      lastError,
    )
      ? CONSULTAS_SYNC_CONFIG.postConsultDisabledRetryMinutes
      : CONSULTAS_SYNC_CONFIG.postConsultRetryMinutes;

    if (
      lastAttempt &&
      now.getTime() - lastAttempt.getTime() <
        retryMinutes * 60 * 1000
    ) {
      skipped.retry_wait = (skipped.retry_wait || 0) + 1;
      continue;
    }

    const response = enviarPosConsulta_(
      {
        appointmentId:
          row[columns[CONSULTAS_SYNC_HEADERS.id]] ||
          `consulta-linha-${index + 1}`,
        patientPhone:
          row[columns[CONSULTAS_SYNC_HEADERS.phone]],
        patientName:
          row[columns[CONSULTAS_SYNC_HEADERS.name]],
        professional:
          row[columns[CONSULTAS_SYNC_HEADERS.professional]] ||
          "Dra. Amanda",
      },
      secret,
      properties,
    );
    sheet
      .getRange(
        rowNumber,
        columns[
          CONSULTAS_SYNC_HEADERS.postLastAttempt
        ] + 1,
      )
      .setValue(now);

    if (response.ok && response.sent) {
      sheet
        .getRange(
          rowNumber,
          columns[CONSULTAS_SYNC_HEADERS.postSentAt] + 1,
        )
        .setValue(now);
      sheet
        .getRange(
          rowNumber,
          columns[
            CONSULTAS_SYNC_HEADERS.postLastError
          ] + 1,
        )
        .clearContent();
      sent += 1;
    } else {
      sheet
        .getRange(
          rowNumber,
          columns[
            CONSULTAS_SYNC_HEADERS.postLastError
          ] + 1,
        )
        .setValue(
          String(
            response.error || "delivery_failed",
          ).slice(0, 180),
        );
      failed += 1;
    }
    } catch (error) {
      failed += 1;
      registrarFalhaLinhaPosConsulta_(
        sheet,
        rowNumber,
        columns,
        now,
        error,
      );
    }
  }

  return {
    ok: failed === 0,
    sent,
    failed,
    suppressed,
    noShowSent,
    noShowManual,
    noShowSuppressed,
    skipped,
  };
}

function enviarPosConsulta_(payload, secret, properties) {
  const endpoint =
    properties.getProperty(
      CONSULTAS_SYNC_CONFIG.postConsultEndpointProperty,
    ) || CONSULTAS_SYNC_CONFIG.postConsultEndpoint;

  try {
    const response = UrlFetchApp.fetch(endpoint, {
      method: "post",
      contentType: "application/json; charset=utf-8",
      headers: {
        "x-liv-secret": secret,
      },
      payload: JSON.stringify(payload),
      muteHttpExceptions: true,
    });
    const responseCode = response.getResponseCode();
    let body = {};

    try {
      body = JSON.parse(response.getContentText() || "{}");
    } catch (error) {
      body = {};
    }

    return {
      ok:
        responseCode >= 200 &&
        responseCode < 300 &&
        body.ok === true,
      sent: body.sent === true,
      error: body.error || `http_${String(responseCode)}`,
    };
  } catch (error) {
    return {
      ok: false,
      sent: false,
      error: "request_failed",
    };
  }
}

function avaliarElegibilidadeRetomadaNaoComparecimento_(
  row,
  columns,
  now,
) {
  const requiredHeaders = [
    CONSULTAS_SYNC_HEADERS.status,
    CONSULTAS_SYNC_HEADERS.noShowAt,
    CONSULTAS_SYNC_HEADERS.noShowEligibleAt,
    CONSULTAS_SYNC_HEADERS.noShowSentAt,
    CONSULTAS_SYNC_HEADERS.noShowSuppressedAt,
  ];
  if (
    requiredHeaders.some(function (header) {
      return columns[header] === undefined;
    })
  ) {
    return { eligible: false, reason: "missing_columns" };
  }
  if (
    !statusNaoCompareceuConsulta_(
      row[columns[CONSULTAS_SYNC_HEADERS.status]],
    )
  ) {
    return { eligible: false, reason: "not_no_show" };
  }
  if (row[columns[CONSULTAS_SYNC_HEADERS.noShowSentAt]]) {
    return { eligible: false, reason: "already_sent" };
  }
  if (row[columns[CONSULTAS_SYNC_HEADERS.noShowSuppressedAt]]) {
    return { eligible: false, reason: "already_suppressed" };
  }
  if (
    !consentimentoPermiteContatoConsultas_(
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.consent,
      ),
      valorDaLinhaConsultas_(
        row,
        columns,
        CONSULTAS_SYNC_HEADERS.source,
      ),
    )
  ) {
    return { eligible: false, reason: "consent_not_confirmed" };
  }

  const lastError = String(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowLastError,
    ) || "",
  );
  if (/manual|whatsapp_window_closed/i.test(lastError)) {
    return { eligible: false, reason: "manual_required" };
  }
  const lastAttempt = dataConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowLastAttempt,
    ),
  );
  if (
    lastAttempt &&
    now.getTime() - lastAttempt.getTime() <
      CONSULTAS_SYNC_CONFIG.postConsultRetryMinutes * 60 * 1000
  ) {
    return { eligible: false, reason: "retry_wait" };
  }

  const noShowAt = dataConsultasSync_(
    row[columns[CONSULTAS_SYNC_HEADERS.noShowAt]],
  );
  const eligibleAt = dataConsultasSync_(
    row[columns[CONSULTAS_SYNC_HEADERS.noShowEligibleAt]],
  );
  if (!noShowAt || !eligibleAt) {
    return { eligible: false, reason: "missing_schedule" };
  }
  if (eligibleAt.getTime() > now.getTime()) {
    return { eligible: false, reason: "not_due" };
  }
  if (
    now.getTime() - noShowAt.getTime() >
    14 * 24 * 60 * 60 * 1000
  ) {
    return { eligible: false, reason: "historical_no_show" };
  }

  return { eligible: true, noShowAt, eligibleAt };
}

function mensagemRetomadaNaoComparecimento_(row, columns) {
  const name = textoConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.name,
    ),
    120,
  );
  const firstName = name ? name.split(/\s+/)[0] : "";
  const professional = textoConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.professional,
    ),
    120,
  ) || "Dra. Amanda";
  const article = chaveProfissionalConsulta_(professional) === "daniel"
    ? "o "
    : "a ";

  return (
    "Oi" +
    (firstName ? ", " + firstName : "") +
    ". Sentimos sua falta na consulta de hoje e esperamos que esteja tudo bem. " +
    "Se ainda fizer sentido para você, posso te ajudar a encontrar um novo horário com " +
    article +
    professional +
    ", com calma."
  );
}

function marcarRetomadaAusenciaManual_(
  sheet,
  rowNumber,
  columns,
  now,
  reason,
) {
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowLastAttempt,
    now,
  );
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowLastError,
    reason,
  );
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowManualAt,
    proximoHorarioDeCuidadoConsultas_(now),
  );
  return { manual: true, reason };
}

function enviarRetomadaNaoComparecimento_(
  payload,
  secret,
  properties,
) {
  const endpoint =
    properties.getProperty(
      CONSULTAS_SYNC_CONFIG.noShowEndpointProperty,
    ) || CONSULTAS_SYNC_CONFIG.noShowEndpoint;

  try {
    const response = UrlFetchApp.fetch(endpoint, {
      method: "post",
      contentType: "application/json; charset=utf-8",
      headers: { "x-liv-secret": secret },
      payload: JSON.stringify(payload),
      muteHttpExceptions: true,
    });
    const responseCode = response.getResponseCode();
    let body = {};
    try {
      body = JSON.parse(response.getContentText() || "{}");
    } catch (error) {
      body = {};
    }

    return {
      ok:
        responseCode >= 200 &&
        responseCode < 300 &&
        body.ok === true,
      sent: body.sent === true,
      error: body.error || `http_${String(responseCode)}`,
    };
  } catch (error) {
    return { ok: false, sent: false, error: "request_failed" };
  }
}

function registrarMensagemNaoComparecimento_(
  spreadsheet,
  row,
  columns,
  phone,
  appointmentId,
  text,
  now,
) {
  const professional = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.professional,
  );
  const leadSheetName = nomePlanilhaLeadProfissional_(professional);
  const leadSheet = leadSheetName
    ? spreadsheet.getSheetByName(leadSheetName)
    : null;
  const leadRow =
    leadSheet && typeof findLeadRowByPhone_ === "function"
      ? findLeadRowByPhone_(leadSheet, phone)
      : null;
  const identifier =
    "no-show-followup-" +
    String(appointmentId || now.getTime())
      .replace(/[^A-Za-z0-9_-]/g, "-")
      .slice(0, 120);

  if (
    leadSheet &&
    leadRow &&
    typeof recordLeadMessageAndQueue_ === "function"
  ) {
    recordLeadMessageAndQueue_(
      spreadsheet,
      leadRow,
      {
        phone,
        messageId: identifier,
        eventId: identifier,
        contactAt: now,
        text,
      },
      "OUT",
    );
    return;
  }

  const messageSheet = spreadsheet.getSheetByName(
    typeof CONFIG !== "undefined" && CONFIG.messageSheetName
      ? CONFIG.messageSheetName
      : "_WHATSAPP_MENSAGENS",
  );
  if (messageSheet) {
    messageSheet.appendRow([
      phone,
      "OUT",
      now,
      identifier,
      identifier,
      text,
      leadRow || "",
    ]);
  }
}

function processarRetomadaNaoComparecimentoNaLinha_(
  sheet,
  rowNumber,
  columns,
  row,
  now,
  secret,
  properties,
  contactPreferences,
  conversation,
) {
  const eligibility = avaliarElegibilidadeRetomadaNaoComparecimento_(
    row,
    columns,
    now,
  );
  if (!eligibility.eligible) {
    return {
      manual: eligibility.reason === "manual_required",
      reason: eligibility.reason,
    };
  }

  if (
    contactPreferences.neverFollowUp === true ||
    contactPreferences.neverBotReply === true
  ) {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowSuppressedAt,
      now,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.suppressionReason,
      "Retomada de ausência suprimida pelas preferências de contato.",
    );
    return { suppressed: true, reason: "contact_preference" };
  }

  const humanInteractionAt = dataConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.lastHumanInteractionAt,
    ),
  );
  const changedAfterNoShow = (conversation || []).some(function (message) {
    return (
      message.dataHora &&
      message.dataHora.getTime() >= eligibility.noShowAt.getTime()
    );
  });
  if (
    changedAfterNoShow ||
    (humanInteractionAt &&
      humanInteractionAt.getTime() >= eligibility.noShowAt.getTime())
  ) {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowSuppressedAt,
      now,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.suppressionReason,
      "Retomada de ausência dispensada: houve interação posterior.",
    );
    return { suppressed: true, reason: "conversation_changed" };
  }

  const phone = normalizarTelefoneConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.phone,
    ),
  );
  const professional = valorDaLinhaConsultas_(
    row,
    columns,
    CONSULTAS_SYNC_HEADERS.professional,
  );
  const noShowCount = contarNaoComparecimentosConsulta_(
    sheet,
    columns,
    phone,
    professional,
  );
  if (noShowCount >= 2) {
    return marcarRetomadaAusenciaManual_(
      sheet,
      rowNumber,
      columns,
      now,
      "repeat_no_show_manual",
    );
  }

  const lastInbound = (conversation || [])
    .slice()
    .reverse()
    .find(function (message) {
      return message.direcao === "IN";
    });
  const minutesSinceInbound = lastInbound
    ? Math.floor(
        (now.getTime() - lastInbound.dataHora.getTime()) / 60000,
      )
    : Infinity;
  if (
    !lastInbound ||
    minutesSinceInbound < 0 ||
    minutesSinceInbound >
      CONSULTAS_SYNC_CONFIG.noShowWhatsappWindowMinutes
  ) {
    return marcarRetomadaAusenciaManual_(
      sheet,
      rowNumber,
      columns,
      now,
      "whatsapp_window_closed_manual",
    );
  }

  const text = mensagemRetomadaNaoComparecimento_(row, columns);
  const appointmentId = textoConsultasSync_(
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_HEADERS.id,
    ),
    160,
  ) || `consulta-linha-${rowNumber}`;
  const result = enviarRetomadaNaoComparecimento_(
    {
      planId: `no-show-${appointmentId}`,
      patientPhone: phone,
      body: text,
    },
    secret,
    properties,
  );
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowLastAttempt,
    now,
  );

  if (result.ok && result.sent) {
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowSentAt,
      now,
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowLastError,
      "",
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.noShowManualAt,
      proximaRetomadaManualAusencia_(now),
    );
    definirValorConsulta_(
      sheet,
      rowNumber,
      columns,
      CONSULTAS_SYNC_HEADERS.nextAction,
      "Aguardar resposta; se não houver, avaliar uma última retomada manual em 5 dias.",
    );
    registrarMensagemNaoComparecimento_(
      sheet.getParent(),
      row,
      columns,
      phone,
      appointmentId,
      text,
      now,
    );
    return { sent: true };
  }

  const error = String(result.error || "delivery_failed");
  if (/disabled|http_400|window|template/i.test(error)) {
    return marcarRetomadaAusenciaManual_(
      sheet,
      rowNumber,
      columns,
      now,
      error + "_manual",
    );
  }
  definirValorConsulta_(
    sheet,
    rowNumber,
    columns,
    CONSULTAS_SYNC_HEADERS.noShowLastError,
    error,
  );
  return { failed: true, reason: error };
}

function diagnosticarPosConsultaSemEnvio() {
  const now = new Date();
  const spreadsheet = SpreadsheetApp.openById(
    CONSULTAS_SYNC_CONFIG.spreadsheetId,
  );
  const sheet = spreadsheet.getSheetByName(
    CONSULTAS_SYNC_CONFIG.consultationsSheetName,
  );

  if (!sheet) {
    throw new Error("A aba Consultas não foi encontrada.");
  }

  if (sheet.getLastRow() < 2) {
    return { ok: true, candidates: 0, counts: {} };
  }

  const values = sheet.getDataRange().getValues();
  const columns = mapearCabecalhosConsultas_(values[0]);
  const counts = {};
  let candidates = 0;

  for (let index = 1; index < values.length; index += 1) {
    const eligibility = avaliarElegibilidadePosConsulta_(
      values[index],
      columns,
      now,
    );
    const reason = eligibility.eligible
      ? "eligible"
      : eligibility.reason;

    counts[reason] = (counts[reason] || 0) + 1;
    if (eligibility.eligible) candidates += 1;
  }

  const result = {
    ok: true,
    checked: Math.max(values.length - 1, 0),
    candidates,
    counts,
  };
  console.log(JSON.stringify(result));
  return result;
}

function avaliarElegibilidadePosConsulta_(row, columns, now) {
  const requiredHeaders = [
    CONSULTAS_SYNC_HEADERS.status,
    CONSULTAS_SYNC_HEADERS.completedDate,
    CONSULTAS_SYNC_HEADERS.consent,
    CONSULTAS_SYNC_HEADERS.source,
    CONSULTAS_SYNC_HEADERS.postEligibleAt,
    CONSULTAS_SYNC_HEADERS.postSentAt,
    CONSULTAS_SYNC_HEADERS.postSuppressedAt,
  ];

  if (
    requiredHeaders.some(function (header) {
      return columns[header] === undefined;
    })
  ) {
    return { eligible: false, reason: "missing_columns" };
  }

  const status = normalizarTextoConsultasSync_(
    row[columns[CONSULTAS_SYNC_HEADERS.status]],
  );

  if (!statusConsultaRealizada_(status)) {
    return { eligible: false, reason: "not_completed" };
  }
  if (row[columns[CONSULTAS_SYNC_HEADERS.postSentAt]]) {
    return { eligible: false, reason: "already_sent" };
  }
  if (row[columns[CONSULTAS_SYNC_HEADERS.postSuppressedAt]]) {
    return { eligible: false, reason: "already_suppressed" };
  }
  if (
    !consentimentoPermiteContatoConsultas_(
      row[columns[CONSULTAS_SYNC_HEADERS.consent]],
      row[columns[CONSULTAS_SYNC_HEADERS.source]],
    )
  ) {
    return {
      eligible: false,
      reason: "consent_not_confirmed",
    };
  }

  const completedAt = dataConsultasSync_(
    row[columns[CONSULTAS_SYNC_HEADERS.completedDate]],
  );
  const completionCheck = validarRecenciaPosConsulta_(
    completedAt,
    now,
  );

  if (!completionCheck.ok) {
    return {
      eligible: false,
      reason: completionCheck.reason,
    };
  }

  const eligibleAt = dataConsultasSync_(
    row[columns[CONSULTAS_SYNC_HEADERS.postEligibleAt]],
  );

  if (!eligibleAt) {
    return { eligible: false, reason: "missing_eligible_at" };
  }
  if (eligibleAt.getTime() > now.getTime()) {
    return { eligible: false, reason: "not_due" };
  }

  return { eligible: true, reason: "eligible", completedAt };
}

function validarRecenciaPosConsulta_(completedAt, now) {
  if (!completedAt) {
    return { ok: false, reason: "missing_completed_at" };
  }

  const ageMilliseconds = now.getTime() - completedAt.getTime();

  if (ageMilliseconds < -5 * 60 * 1000) {
    return { ok: false, reason: "future_completed_at" };
  }
  if (
    ageMilliseconds >
    CONSULTAS_SYNC_CONFIG.postConsultMaxAgeDays *
      24 *
      60 *
      60 *
      1000
  ) {
    return { ok: false, reason: "historical_completed_at" };
  }

  return { ok: true, reason: "recent_completed_at" };
}

function registrarFalhaLinhaPosConsulta_(
  sheet,
  rowNumber,
  columns,
  now,
  error,
) {
  const errorCode = "row_processing_failed";

  try {
    const attemptColumn =
      columns[CONSULTAS_SYNC_HEADERS.postLastAttempt];
    const errorColumn =
      columns[CONSULTAS_SYNC_HEADERS.postLastError];

    if (attemptColumn !== undefined) {
      sheet
        .getRange(rowNumber, attemptColumn + 1)
        .setValue(now);
    }
    if (errorColumn !== undefined) {
      sheet
        .getRange(rowNumber, errorColumn + 1)
        .setValue(errorCode);
    }
  } catch (writeError) {
    console.error(
      JSON.stringify({
        event: "post_consult_error_record_failed",
        row: rowNumber,
      }),
    );
  }

  console.error(
    JSON.stringify({
      event: "post_consult_row_failed",
      row: rowNumber,
      code: errorCode,
      detail: textoConsultasSync_(
        error && error.message ? error.message : error,
        120,
      ),
    }),
  );
}

function statusCanonicoLeadDaConsulta_(status) {
  const normalized = normalizarTextoConsultasSync_(status);
  if (statusConsultaRealizada_(normalized)) {
    return "Consulta realizada";
  }
  if ([
    "agendada",
    "confirmada",
    "remarcada",
    "consulta agendada",
    "consulta confirmada",
  ].includes(normalized)) {
    return "Consulta agendada";
  }
  return "";
}

function atualizarStatusLeadDaConsulta_(
  spreadsheet,
  phoneValue,
  professional,
  status,
) {
  const canonicalStatus = statusCanonicoLeadDaConsulta_(status);
  if (!canonicalStatus) return;

  const phone = normalizarTelefoneConsultasSync_(phoneValue);

  if (!phone) return;

  const preferredSheet = nomePlanilhaLeadProfissional_(professional);
  if (!preferredSheet) return;
  const sheet = spreadsheet.getSheetByName(preferredSheet);

  if (!sheet || sheet.getLastRow() < 2) return;

  const headers = sheet
    .getRange(1, 1, 1, sheet.getLastColumn())
    .getDisplayValues()[0];
  const columns = mapearCabecalhosConsultas_(headers);
  const phoneColumn =
    columns[CONSULTAS_SYNC_LEAD_HEADERS.phone];
  const statusColumn =
    columns[CONSULTAS_SYNC_LEAD_HEADERS.status];
  const statusDateColumn =
    columns[CONSULTAS_SYNC_LEAD_HEADERS.statusDate];

  if (phoneColumn === undefined || statusColumn === undefined) {
    return;
  }

  const phones = sheet
    .getRange(2, phoneColumn + 1, sheet.getLastRow() - 1, 1)
    .getDisplayValues();

  for (let index = phones.length - 1; index >= 0; index -= 1) {
    if (
      normalizarTelefoneConsultasSync_(phones[index][0]) !==
      phone
    ) {
      continue;
    }

    const rowNumber = index + 2;
    const currentStatus = String(
      sheet.getRange(rowNumber, statusColumn + 1).getDisplayValue() ||
      "Novo",
    );
    const shouldApply = typeof shouldApplyLeadStatus_ === "function"
      ? shouldApplyLeadStatus_(currentStatus, canonicalStatus, "high")
      : currentStatus !== "Paciente convertido";

    if (!shouldApply) return;

    sheet
      .getRange(rowNumber, statusColumn + 1)
      .setValue(canonicalStatus);

    if (statusDateColumn !== undefined) {
      sheet
        .getRange(rowNumber, statusDateColumn + 1)
        .setValue(
          Utilities.formatDate(
            new Date(),
            CONSULTAS_SYNC_CONFIG.timezone,
            "dd/MM/yyyy",
          ),
        );
    }

    if (
      sheet.getName() === "Google Ads - Conversões" &&
      typeof recordLeadStageEvent_ === "function"
    ) {
      const leadValues = sheet
        .getRange(rowNumber, 1, 1, sheet.getLastColumn())
        .getDisplayValues()[0];
      recordLeadStageEvent_(spreadsheet, {
        opportunityId: typeof leadOpportunityId_ === "function"
          ? leadOpportunityId_(leadValues, phone)
          : "",
        phone,
        source: "consultas_sync",
        fromStatus: currentStatus,
        proposedStatus: canonicalStatus,
        appliedStatus: canonicalStatus,
        confidence: "structured",
        decision: "applied",
        evidence: "Status estruturado da aba Consultas",
      });
    }
    return;
  }
}

function nomePlanilhaLeadProfissional_(professional) {
  const key = chaveProfissionalConsulta_(professional);
  if (key === "amanda") return "Google Ads - Conversões";
  if (key === "daniel") return "Leads Dr. Daniel";
  return "";
}

function garantirEstruturaAgendaVisivelLeads_(sheet) {
  const lastColumn = Math.max(sheet.getLastColumn(), 1);
  const headers = sheet
    .getRange(1, 1, 1, lastColumn)
    .getDisplayValues()[0]
    .map(function (value) {
      return String(value || "").trim();
    });
  const appointmentHeaders = [
    CONSULTAS_SYNC_LEAD_HEADERS.appointmentDate,
    CONSULTAS_SYNC_LEAD_HEADERS.appointmentTime,
    CONSULTAS_SYNC_LEAD_HEADERS.appointmentProfessional,
    CONSULTAS_SYNC_LEAD_HEADERS.appointmentRoom,
    CONSULTAS_SYNC_LEAD_HEADERS.appointmentOutcome,
    CONSULTAS_SYNC_LEAD_HEADERS.lastNoShowAt,
    CONSULTAS_SYNC_LEAD_HEADERS.noShowCount,
  ];

  appointmentHeaders.forEach(function (header) {
    if (mapearCabecalhosConsultas_(headers)[header] !== undefined) {
      return;
    }
    if (
      typeof sheet.getMaxColumns === "function" &&
      typeof sheet.insertColumnsAfter === "function" &&
      headers.length >= sheet.getMaxColumns()
    ) {
      sheet.insertColumnsAfter(sheet.getMaxColumns(), 7);
    }
    headers.push(header);
    sheet.getRange(1, headers.length).setValue(header);
  });

  const columns = mapearCabecalhosConsultas_(headers);
  const widths = {
    [CONSULTAS_SYNC_LEAD_HEADERS.appointmentDate]: 125,
    [CONSULTAS_SYNC_LEAD_HEADERS.appointmentTime]: 125,
    [CONSULTAS_SYNC_LEAD_HEADERS.appointmentProfessional]: 180,
    [CONSULTAS_SYNC_LEAD_HEADERS.appointmentRoom]: 110,
    [CONSULTAS_SYNC_LEAD_HEADERS.appointmentOutcome]: 170,
    [CONSULTAS_SYNC_LEAD_HEADERS.lastNoShowAt]: 170,
    [CONSULTAS_SYNC_LEAD_HEADERS.noShowCount]: 160,
  };
  Object.keys(widths).forEach(function (header) {
    sheet.setColumnWidth(columns[header] + 1, widths[header]);
  });

  return columns;
}

function formatarDataVisivelConsulta_(value) {
  const iso = extrairDataConsultasSync_(value);
  if (!iso) return "";
  const parts = iso.split("-");
  return [parts[2], parts[1], parts[0]].join("/");
}

function atualizarAgendaVisivelNoLead_(
  spreadsheet,
  phoneValue,
  professional,
  appointment,
) {
  const phone = normalizarTelefoneConsultasSync_(phoneValue);
  const preferredSheet = nomePlanilhaLeadProfissional_(professional);
  if (!phone || !preferredSheet) return false;

  const sheet = spreadsheet.getSheetByName(preferredSheet);
  if (!sheet || sheet.getLastRow() < 2) return false;

  const columns = garantirEstruturaAgendaVisivelLeads_(sheet);
  const phoneColumn = columns[CONSULTAS_SYNC_LEAD_HEADERS.phone];
  if (phoneColumn === undefined) return false;

  const phones = sheet
    .getRange(2, phoneColumn + 1, sheet.getLastRow() - 1, 1)
    .getDisplayValues();

  for (let index = phones.length - 1; index >= 0; index -= 1) {
    if (
      normalizarTelefoneConsultasSync_(phones[index][0]) !== phone
    ) {
      continue;
    }

    const rowNumber = index + 2;
    const values = [
      [
        CONSULTAS_SYNC_LEAD_HEADERS.appointmentDate,
        formatarDataVisivelConsulta_(appointment.scheduledDate),
      ],
      [
        CONSULTAS_SYNC_LEAD_HEADERS.appointmentTime,
        extrairHorarioConsultasSync_(appointment.scheduledTime),
      ],
      [
        CONSULTAS_SYNC_LEAD_HEADERS.appointmentProfessional,
        professional,
      ],
      [
        CONSULTAS_SYNC_LEAD_HEADERS.appointmentRoom,
        normalizarSalaConsulta_(appointment.room),
      ],
    ];

    values.forEach(function (entry) {
      if (entry[1] === "") return;
      sheet
        .getRange(rowNumber, columns[entry[0]] + 1)
        .setValue(entry[1]);
    });
    return true;
  }

  return false;
}

function atualizarResumoNaoComparecimentoNoLead_(
  spreadsheet,
  consultationSheet,
  phoneValue,
  professional,
) {
  const phone = normalizarTelefoneConsultasSync_(phoneValue);
  const preferredSheet = nomePlanilhaLeadProfissional_(professional);
  if (!phone || !preferredSheet) return false;

  const leadSheet = spreadsheet.getSheetByName(preferredSheet);
  if (!leadSheet || leadSheet.getLastRow() < 2) return false;

  const consultationHeaders = consultationSheet
    .getRange(1, 1, 1, consultationSheet.getLastColumn())
    .getDisplayValues()[0];
  const consultationColumns = mapearCabecalhosConsultas_(
    consultationHeaders,
  );
  const count = contarNaoComparecimentosConsulta_(
    consultationSheet,
    consultationColumns,
    phone,
    professional,
  );
  const rows = consultationSheet.getLastRow() >= 2
    ? consultationSheet
        .getRange(
          2,
          1,
          consultationSheet.getLastRow() - 1,
          consultationSheet.getLastColumn(),
        )
        .getValues()
    : [];
  let latest = null;

  rows.forEach(function (row) {
    if (
      normalizarTelefoneConsultasSync_(
        row[consultationColumns[CONSULTAS_SYNC_HEADERS.phone]],
      ) !== phone ||
      chaveProfissionalConsulta_(
        row[consultationColumns[CONSULTAS_SYNC_HEADERS.professional]],
      ) !== chaveProfissionalConsulta_(professional) ||
      !statusNaoCompareceuConsulta_(
        row[consultationColumns[CONSULTAS_SYNC_HEADERS.status]],
      )
    ) {
      return;
    }

    const candidate =
      dataConsultasSync_(
        row[consultationColumns[CONSULTAS_SYNC_HEADERS.noShowAt]],
      ) ||
      dataConsultasSync_(
        row[consultationColumns[CONSULTAS_SYNC_HEADERS.scheduledDate]],
      );
    if (candidate && (!latest || candidate.getTime() > latest.getTime())) {
      latest = candidate;
    }
  });

  const columns = garantirEstruturaAgendaVisivelLeads_(leadSheet);
  const phoneColumn = columns[CONSULTAS_SYNC_LEAD_HEADERS.phone];
  const phones = leadSheet
    .getRange(2, phoneColumn + 1, leadSheet.getLastRow() - 1, 1)
    .getDisplayValues();

  for (let index = phones.length - 1; index >= 0; index -= 1) {
    if (normalizarTelefoneConsultasSync_(phones[index][0]) !== phone) {
      continue;
    }
    const rowNumber = index + 2;
    leadSheet
      .getRange(
        rowNumber,
        columns[CONSULTAS_SYNC_LEAD_HEADERS.appointmentOutcome] + 1,
      )
      .setValue("Não compareceu");
    leadSheet
      .getRange(
        rowNumber,
        columns[CONSULTAS_SYNC_LEAD_HEADERS.noShowCount] + 1,
      )
      .setValue(count);
    if (latest) {
      leadSheet
        .getRange(
          rowNumber,
          columns[CONSULTAS_SYNC_LEAD_HEADERS.lastNoShowAt] + 1,
        )
        .setValue(latest);
    }
    return true;
  }

  return false;
}

function garantirEstruturaSincronizacaoConsultas_(sheet) {
  const lastColumn = Math.max(sheet.getLastColumn(), 1);
  const headers = sheet
    .getRange(1, 1, 1, lastColumn)
    .getDisplayValues()[0]
    .map(function (value) {
      return String(value || "").trim();
    });
  const columns = mapearCabecalhosConsultas_(headers);
  const requiredExisting = [
    CONSULTAS_SYNC_HEADERS.id,
    CONSULTAS_SYNC_HEADERS.phone,
    CONSULTAS_SYNC_HEADERS.professional,
    CONSULTAS_SYNC_HEADERS.status,
  ];

  requiredExisting.forEach(function (header) {
    if (columns[header] === undefined) {
      throw new Error(
        `Coluna obrigatória ausente em Consultas: ${header}`,
      );
    }
  });

  [
    CONSULTAS_SYNC_HEADERS.opportunityId,
    CONSULTAS_SYNC_HEADERS.room,
    CONSULTAS_SYNC_HEADERS.durationMinutes,
    CONSULTAS_SYNC_HEADERS.calendarId,
    CONSULTAS_SYNC_HEADERS.calendarEventId,
    CONSULTAS_SYNC_HEADERS.calendarSyncStatus,
    CONSULTAS_SYNC_HEADERS.calendarSyncError,
    CONSULTAS_SYNC_HEADERS.noShowAt,
    CONSULTAS_SYNC_HEADERS.noShowEligibleAt,
    CONSULTAS_SYNC_HEADERS.noShowSentAt,
    CONSULTAS_SYNC_HEADERS.noShowLastAttempt,
    CONSULTAS_SYNC_HEADERS.noShowLastError,
    CONSULTAS_SYNC_HEADERS.noShowSuppressedAt,
    CONSULTAS_SYNC_HEADERS.noShowManualAt,
    CONSULTAS_SYNC_HEADERS.postEligibleAt,
    CONSULTAS_SYNC_HEADERS.postSentAt,
    CONSULTAS_SYNC_HEADERS.postLastAttempt,
    CONSULTAS_SYNC_HEADERS.postLastError,
    CONSULTAS_SYNC_HEADERS.postSuppressedAt,
    CONSULTAS_SYNC_HEADERS.patientConfirmedAt,
    CONSULTAS_SYNC_HEADERS.lastHumanInteractionAt,
    CONSULTAS_SYNC_HEADERS.nextAction,
    CONSULTAS_SYNC_HEADERS.suppressionReason,
  ].forEach(function (header) {
    if (columns[header] === undefined) {
      if (
        typeof sheet.getMaxColumns === "function" &&
        typeof sheet.insertColumnsAfter === "function" &&
        headers.length >= sheet.getMaxColumns()
      ) {
        sheet.insertColumnsAfter(sheet.getMaxColumns(), 10);
      }
      headers.push(header);
      sheet.getRange(1, headers.length).setValue(header);
      columns[header] = headers.length - 1;
    }
  });

  const controlWidths = {
    [CONSULTAS_SYNC_HEADERS.opportunityId]: 190,
    [CONSULTAS_SYNC_HEADERS.room]: 90,
    [CONSULTAS_SYNC_HEADERS.durationMinutes]: 105,
    [CONSULTAS_SYNC_HEADERS.calendarId]: 210,
    [CONSULTAS_SYNC_HEADERS.calendarEventId]: 210,
    [CONSULTAS_SYNC_HEADERS.calendarSyncStatus]: 210,
    [CONSULTAS_SYNC_HEADERS.calendarSyncError]: 220,
    [CONSULTAS_SYNC_HEADERS.noShowAt]: 190,
    [CONSULTAS_SYNC_HEADERS.noShowEligibleAt]: 210,
    [CONSULTAS_SYNC_HEADERS.noShowSentAt]: 190,
    [CONSULTAS_SYNC_HEADERS.noShowLastAttempt]: 220,
    [CONSULTAS_SYNC_HEADERS.noShowLastError]: 210,
    [CONSULTAS_SYNC_HEADERS.noShowSuppressedAt]: 210,
    [CONSULTAS_SYNC_HEADERS.noShowManualAt]: 230,
    [CONSULTAS_SYNC_HEADERS.postEligibleAt]: 170,
    [CONSULTAS_SYNC_HEADERS.postSentAt]: 155,
    [CONSULTAS_SYNC_HEADERS.postLastAttempt]: 195,
    [CONSULTAS_SYNC_HEADERS.postLastError]: 180,
    [CONSULTAS_SYNC_HEADERS.postSuppressedAt]: 180,
    [CONSULTAS_SYNC_HEADERS.patientConfirmedAt]: 170,
    [CONSULTAS_SYNC_HEADERS.lastHumanInteractionAt]: 180,
    [CONSULTAS_SYNC_HEADERS.nextAction]: 220,
    [CONSULTAS_SYNC_HEADERS.suppressionReason]: 260,
  };

  Object.keys(controlWidths).forEach(function (header) {
    const column = columns[header];
    if (column !== undefined) {
      sheet.setColumnWidth(
        column + 1,
        controlWidths[header],
      );
    }
  });
}

function mapearCabecalhosConsultas_(headers) {
  const result = {};
  const normalizedIndexes = {};

  headers.forEach(function (value, index) {
    const header = String(value || "").trim();
    if (header && result[header] === undefined) {
      result[header] = index;
    }
    const normalized = normalizarCabecalhoConsultas_(header);
    if (
      normalized &&
      normalizedIndexes[normalized] === undefined
    ) {
      normalizedIndexes[normalized] = index;
    }
  });

  [
    ...Object.values(CONSULTAS_SYNC_HEADERS),
    ...Object.values(CONSULTAS_SYNC_LEAD_HEADERS),
  ].forEach(function (canonicalHeader) {
    if (result[canonicalHeader] !== undefined) return;

    const normalized = normalizarCabecalhoConsultas_(
      canonicalHeader,
    );
    const index = normalizedIndexes[normalized];

    if (index !== undefined) {
      result[canonicalHeader] = index;
    }
  });

  const aliases = {
    [CONSULTAS_SYNC_HEADERS.source]: [
      "origem do lead",
      "fonte da sincronizacao",
    ],
    [CONSULTAS_SYNC_HEADERS.notes]: [
      "resumo administrativo",
    ],
  };

  Object.keys(aliases).forEach(function (canonicalHeader) {
    if (result[canonicalHeader] !== undefined) return;

    for (let index = 0; index < aliases[canonicalHeader].length; index += 1) {
      const alias = aliases[canonicalHeader][index];
      if (normalizedIndexes[alias] !== undefined) {
        result[canonicalHeader] =
          normalizedIndexes[alias];
        break;
      }
    }
  });

  return result;
}

function normalizarCabecalhoConsultas_(value) {
  return corrigirMojibakeCabecalhoConsultas_(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9]+/g, " ")
    .trim()
    .toLowerCase();
}

function corrigirMojibakeCabecalhoConsultas_(value) {
  return String(value || "")
    .replace(/Ã¡/g, "á")
    .replace(/Ã¢/g, "â")
    .replace(/Ã£/g, "ã")
    .replace(/Ã©/g, "é")
    .replace(/Ãª/g, "ê")
    .replace(/Ã­/g, "í")
    .replace(/Ã³/g, "ó")
    .replace(/Ã´/g, "ô")
    .replace(/Ãµ/g, "õ")
    .replace(/Ãº/g, "ú")
    .replace(/Ã§/g, "ç")
    .replace(/Â/g, "");
}

function definirValorConsulta_(
  sheet,
  row,
  columns,
  header,
  value,
) {
  const column = columns[header];
  if (column === undefined) return;
  const safeValue =
    header === CONSULTAS_SYNC_HEADERS.status
      ? statusCanonicoConsultas_(value)
      : value;
  sheet.getRange(row, column + 1).setValue(safeValue);
}

function statusCanonicoConsultas_(value) {
  const normalized = normalizarTextoConsultasSync_(value);
  const statuses = {
    "aguardando confirmacao": "Aguardando confirmação",
    agendada: "Agendada",
    "consulta agendada": "Agendada",
    confirmada: "Confirmada",
    "consulta confirmada": "Confirmada",
    realizada: "Realizada",
    "consulta realizada": "Realizada",
    remarcada: "Remarcada",
    "reagendamento solicitado": "Remarcada",
    cancelada: "Cancelada",
    "nao compareceu": "Não compareceu",
  };

  return statuses[normalized] || value;
}

function valorDaLinhaConsultas_(row, columns, header) {
  const column = columns[header];
  return column === undefined ? "" : row[column];
}

function montarObservacaoLeadConsultas_(
  row,
  columns,
  sheetName,
) {
  const details = [
    `Origem: ${sheetName}`,
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_LEAD_HEADERS.reference,
    ),
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_LEAD_HEADERS.platform,
    ),
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_LEAD_HEADERS.campaign,
    ),
    valorDaLinhaConsultas_(
      row,
      columns,
      CONSULTAS_SYNC_LEAD_HEADERS.creative,
    ),
  ]
    .map(function (value) {
      return String(value || "").trim();
    })
    .filter(Boolean);

  return details.join(" | ").slice(0, 500);
}

function construirIdConsulta_(phone, input, row, now) {
  const date =
    extrairDataConsultasSync_(input.scheduledDate) ||
    Utilities.formatDate(
      now,
      CONSULTAS_SYNC_CONFIG.timezone,
      "yyyyMMdd",
    );
  const time =
    extrairHorarioConsultasSync_(input.scheduledTime) ||
    String(row);

  return (
    "consulta-" +
    phone.replace(/\D/g, "") +
    "-" +
    date.replace(/\D/g, "") +
    "-" +
    time.replace(/\D/g, "")
  ).slice(0, 180);
}

function mesmaDataConsulta_(left, right) {
  return (
    extrairDataConsultasSync_(left) &&
    extrairDataConsultasSync_(left) ===
      extrairDataConsultasSync_(right)
  );
}

function mesmoHorarioConsulta_(left, right) {
  return (
    extrairHorarioConsultasSync_(left) &&
    extrairHorarioConsultasSync_(left) ===
      extrairHorarioConsultasSync_(right)
  );
}

function extrairDataConsultasSync_(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return Utilities.formatDate(
      value,
      CONSULTAS_SYNC_CONFIG.timezone,
      "yyyy-MM-dd",
    );
  }

  const text = String(value || "").trim();
  let match = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (match) return `${match[1]}-${match[2]}-${match[3]}`;

  match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})/);
  if (!match) return "";

  return [
    match[3],
    String(match[2]).padStart(2, "0"),
    String(match[1]).padStart(2, "0"),
  ].join("-");
}

function extrairHorarioConsultasSync_(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return Utilities.formatDate(
      value,
      CONSULTAS_SYNC_CONFIG.timezone,
      "HH:mm",
    );
  }

  const match = String(value || "")
    .trim()
    .match(/^(\d{1,2}):(\d{2})/);

  if (!match) return "";

  return (
    String(Number(match[1])).padStart(2, "0") +
    ":" +
    match[2]
  );
}

function dataConsultasSync_(value) {
  if (value instanceof Date && !Number.isNaN(value.getTime())) {
    return value;
  }

  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function normalizarTelefoneConsultasSync_(value) {
  const digits = String(value || "").replace(/\D/g, "");
  return digits.length >= 10 && digits.length <= 15
    ? `+${digits}`
    : "";
}

function textoConsultasSync_(value, maximumLength) {
  return String(value || "")
    .trim()
    .slice(0, maximumLength);
}

function normalizarTextoConsultasSync_(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim()
    .toLowerCase();
}

function statusAgendaConsulta_(status) {
  return [
    "agendada",
    "confirmada",
    "consulta agendada",
    "consulta confirmada",
    "realizada",
    "consulta realizada",
  ].includes(status);
}

function statusConsultaRealizada_(status) {
  return ["realizada", "consulta realizada"].includes(status);
}

function consentimentoPermiteContatoConsultas_(value, source) {
  const normalizedValue = normalizarTextoConsultasSync_(value);
  const normalizedSource = normalizarTextoConsultasSync_(source);
  const explicitNegative = [
    "nao",
    "nao autorizado",
    "sem consentimento",
    "false",
    "falso",
    "0",
  ];
  const explicitPositive = [
    "sim",
    "autorizado",
    "autorizada",
    "permitido",
    "permitida",
    "true",
    "verdadeiro",
    "1",
  ];

  if (explicitNegative.includes(normalizedValue)) return false;
  if (explicitPositive.includes(normalizedValue)) return true;

  return !(
    normalizedSource.includes("prontuario") &&
    normalizedSource.includes("google drive")
  );
}

function estaNoHorarioConsultasSync_(date) {
  const hour = Number(
    Utilities.formatDate(
      date,
      CONSULTAS_SYNC_CONFIG.timezone,
      "H",
    ),
  );

  return (
    hour >= CONSULTAS_SYNC_CONFIG.startHour &&
    hour < CONSULTAS_SYNC_CONFIG.endHour
  );
}
